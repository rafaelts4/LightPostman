﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace TabCmd
{
    public class CarouselQueue<T> : Queue<T>
    {
        public event Action<T> OnEnqueue;
        public event Action<T> OnDequeue;
        public int Limit { get; private set; }

        public CarouselQueue(int limit = -1)
        {
            Limit = limit;
        }

        public new void Enqueue(T item)
        {

            OnEnqueue?.Invoke(item);
            base.Enqueue(item);
            while (Limit > 0 && Count > Limit)
            {
                Dequeue();
            }
        }

        public new T Dequeue()
        {
            var item = base.Dequeue();
            OnDequeue?.Invoke(item);
            return item;
        }
    }

    public class CarouselList<T> : List<T>
    {
        public event Action<T> OnAdd;
        public event Action<T> OnRemove;
        public int Limit { get; private set; }

        public CarouselList(int limit = -1)
        {
            Limit = limit;
        }

        public new void Add(T item)
        {
            OnAdd?.Invoke(item);
            base.Add(item);
            while (Limit > 0 && Count > Limit)
            {
                Remove(this.LastOrDefault());
            }
        }

        public new T Remove(T item)
        {
            if (item != null && base.Remove(item))
            {
                OnRemove?.Invoke(item);
                return item;
            }
            return default;
        }
    }
}
