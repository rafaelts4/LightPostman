﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TabCmd
{
    public partial class PromptForm : Form
    {
        public PromptForm()
        {
            InitializeComponent();                       
        }

        private void PromptForm_Load(object sender, EventArgs e)
        {                        
            tabControl.TabPages[0].Controls.Add(new PromptComandControl());            
            tabControl.SelectedIndex = 0;
        }

        private async void tabControl_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tabControl.SelectedTab == tabPagePlus)
            {
                tabControl.MouseDown -= tabControl_MouseDown;
                var tabIndex = tabControl.TabPages.Count - 1;
                tabControl.TabPages.Insert(tabIndex, tabControl.TabPages.Count.ToString());
                tabControl.TabPages[tabIndex].Controls.Add(new PromptComandControl());
                tabControl.SelectedIndex = tabIndex;
                await Task.Delay(250);
                tabControl.MouseDown += tabControl_MouseDown;
            }
            Text = $"Prompt de Comando [{tabControl.SelectedTab.Text}]";
        }

        private void tabControl_DrawItem(object sender, DrawItemEventArgs e)
        {
            try
            {
                //This code will render a "x" mark at the end of the Tab caption. 
                if (e.Index >= tabControl.TabPages.Count - 1) 
                    return;
                e.Graphics.DrawString(" x", new Font(e.Font, FontStyle.Bold), Brushes.Firebrick, e.Bounds.Right - 20, e.Bounds.Top + 4);
                e.Graphics.DrawString(tabControl.TabPages[e.Index].Text, e.Font, Brushes.Black, e.Bounds.Left + 12, e.Bounds.Top + 4);
                e.DrawFocusRectangle();
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }
        }

        private void tabControl_MouseDown(object sender, MouseEventArgs e)
        {
            // Looping through the controls.
            for (int i = 0; i < this.tabControl.TabPages.Count; i++)
            {
                if (tabControl.TabPages[i].Text == "+")
                    continue;
                Rectangle r = tabControl.GetTabRect(i);
                //Getting the position of the "x" mark.
                Rectangle closeButton = new Rectangle(r.Right - 15, r.Top + 4, 9, 7);
                if (closeButton.Contains(e.Location))
                {
                    tabControl.TabPages.RemoveAt(i);                
                }
            }
        }
    }
}