﻿using System;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TabCmd
{
    using System.Diagnostics;
    using System.Security;
    
    public partial class PromptComandControl : UserControl
    {        
        readonly Keys[] teclasPermitidas = new Keys[] { Keys.Enter, Keys.Left, Keys.Right, Keys.Up, Keys.Down, Keys.PageUp, Keys.PageDown, Keys.Shift, Keys.Control, Keys.Alt, Keys.CapsLock, Keys.End };
        string cmdInputBuffer, cmdOutputBuffer;
        CarouselList<string> commandHistory;
        AutoResetEvent waitHandle;
        Process cmd;

        public PromptComandControl()
        {
            InitializeComponent();
            Dock = DockStyle.Fill;
            commandHistory = new CarouselList<string>(30);
            waitHandle = new AutoResetEvent(true);
            cmdInputBuffer = cmdOutputBuffer = string.Empty;
        }

        private void txtInput_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13 && cmd != null)
            {
                cmd.StandardInput.WriteLine(cmdInputBuffer.Trim());
                cmdInputBuffer = string.Empty;
                txtInput.SelectionStart = txtInput.Text.Length;
                txtInput.SelectionLength = 0;
                txtInput.ScrollToCaret();
                commandHistory.Add(cmdInputBuffer.Trim());
            }
            else if (e.KeyChar == '\b')
            {
                if (cmdInputBuffer.Length > 0)
                {
                    cmdInputBuffer = cmdInputBuffer.Remove(cmdInputBuffer.Length - 1);
                }
            }            
            else
            {
                cmdInputBuffer += e.KeyChar;
                cmdInputBuffer = RemoveNonGraphicalChar(cmdInputBuffer);
            }
        }

        private void txtInput_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                //Libera entradas que não alteram texto.
                if (teclasPermitidas.Any(k => k == e.KeyCode))
                    return;
                //Impede que o output seja apagado com o backspace.
                if (e.KeyCode == Keys.Back)
                {
                    e.Handled = (txtInput.SelectionStart <= txtInput.TextLength - cmdInputBuffer.Length);
                    return;
                }
                //Impede alteração do texto anterior ao input.                               
                e.Handled = txtInput.SelectionStart < txtInput.TextLength;
            }
            finally
            {
                e.SuppressKeyPress = e.Handled;
            }
        }

        private void cmd_OutputDataReceived(object sender, DataReceivedEventArgs e)
        {
            WriteInput(e.Data);
            Invoke(txtInput, ScrollToTheEnd);            
            waitHandle.Set();
        }

        private void Invoke(Control ctrl, Action act)
        {            
            if (ctrl.InvokeRequired)
                ctrl.Invoke(act);
            else
                act.Invoke();
        }

        private void PromptComandControl_Load(object sender, EventArgs e)
        {            
            cmd = new Process();

            cmd.EnableRaisingEvents = true;
            cmd.StartInfo.UseShellExecute = false;
            cmd.StartInfo.FileName = "cmd.exe";
            cmd.StartInfo.CreateNoWindow = true;
            cmd.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;

            cmd.StartInfo.RedirectStandardError = true;
            cmd.StartInfo.RedirectStandardInput = true;
            cmd.StartInfo.RedirectStandardOutput = true;

            //Não funciona com UseShellExecute igual a false.
            //RunAs();            
            cmd.OutputDataReceived += cmd_OutputDataReceived;
            cmd.ErrorDataReceived += cmd_OutputDataReceived;

            cmd.Start();
            cmd.BeginErrorReadLine();

            Task.Factory.StartNew(() =>
            {
                int c = -1;
                while (true)
                {
                    c = cmd.StandardOutput.Peek();
                    if (c == -1 && !string.IsNullOrEmpty(cmdOutputBuffer))
                    {
                        cmdOutputBuffer = RemoveNonGraphicalChar(cmdOutputBuffer);
                        if (cmdOutputBuffer?.ToLower().Trim() == "cls")
                            WriteInput(string.Empty, false);
                        else
                        {
                            //Aguarda término de output antes de imprimir.
                            waitHandle.WaitOne(250);
                            WriteInput(cmdOutputBuffer);
                        }
                        cmdOutputBuffer = string.Empty;
                    }
                    else
                    {
                        cmdOutputBuffer += (char)cmd.StandardOutput.Read();
                    }
                }
            });
            txtInput.Focus();
            txtInput.Select();
        }

        private string RemoveNonGraphicalChar(string s)
        {
            if (string.IsNullOrEmpty(s))
                return s;

            var sb = new StringBuilder();
            var removidos = string.Empty;
            foreach (var c in s)
            {
                if ((c >= 33 && c <= 255 && c != 143 && c != 144)
                    || c == '\n' || c == '\r' || c == '\t' || c == ' ' || c == '‚')
                    sb.Append(c);
                else
                    removidos += c;
            }
            Debug.WriteLine("Removidos: " + removidos);
            return sb.ToString();
        }

        private void WriteInput(string text, bool append = true)
        {
            Action action = () =>
            {
                if (append)
                    txtInput.Text += text;
                else
                    txtInput.Text = text;
                ScrollToTheEnd();
            };
            Invoke(txtInput, action);
        }

        private void ScrollToTheEnd()
        {
            txtInput.SelectionStart = txtInput.Text.Length;
            txtInput.SelectionLength = 0;
            txtInput.ScrollToCaret();
        }        
        
        static string adminPassword = null;
        private bool RunAsAdmin()
        {
            if (adminPassword != null)
                return false;

            var frmPrompt = new Form()
            {
                FormBorderStyle = FormBorderStyle.FixedToolWindow,
                Height = 110,
                Width = 180,
                Text = "Run as Admin ?",
                ControlBox = false,
            };
            frmPrompt.Controls.AddRange(new Control[] {
                new Button {Name = "btnYes", Text = "Yes", DialogResult = DialogResult.Yes, Dock = DockStyle.Left},
                new Button {Name = "btnNo", Text = "No", DialogResult = DialogResult.No, Dock = DockStyle.Right},
                new TextBox {Name = "txtInput", Dock = DockStyle.Top, PasswordChar = '•'},
                new Label() {Text = "Senha: ", Dock = DockStyle.Top,},
            });
            frmPrompt.AcceptButton = frmPrompt.Controls["btnYes"] as Button;

            if (frmPrompt.ShowDialog() == DialogResult.No)
            {
                adminPassword = String.Empty;
                return false;
            }

            adminPassword = frmPrompt.Controls["txtInput"].Text;
            if (string.IsNullOrWhiteSpace(adminPassword))
            {
                adminPassword = null;
                return false;
            }
            else
            {
                cmd.StartInfo.Verb = "runas";
                cmd.StartInfo.UserName = Environment.UserName;
                var secureString = new SecureString();
                foreach (char letter in adminPassword.ToArray())
                {
                    secureString.AppendChar(letter);
                }
                cmd.StartInfo.Password = secureString;
                return true;
            }
        }
    }
}