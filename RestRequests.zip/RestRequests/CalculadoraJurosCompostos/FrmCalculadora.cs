﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;

namespace CalculadoraJurosCompostos
{
    public partial class FrmCalculadora : Form
    {
        const string FORMULA_M = @"{\rtf1\ansi\ansicpg1252\deff0\deflang1046{\fonttbl{\f0\fnil\fcharset0 Calibri;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}\viewkind4\uc1\pard\lang22\f0\fs22 M = C (1 + t) \super t\lang1046\nosupersub\f1\fs17\par}";
        const string FORMULA_C = @"{\rtf1\ansi\ansicpg1252\deff0\deflang1046{\fonttbl{\f0\fnil\fcharset0 Calibri;}{\f1\fnil\fcharset0 Microsoft Sans Serif;}}\viewkind4\uc1\pard\lang22\f0\fs22 M = C (1 + t) \super t\lang1046\nosupersub\f1\fs17\par}";
        const string FORMULA_t = @"{\rtf1\ansi\ansicpg1252\deff0\deflang1046{\fonttbl{\f0\fnil\fcharset0 Calibri;}}\viewkind4\uc1\pard\sl276\slmult1\lang22\f0\fs22 t = \super\i ln\i0 (M/C)\nosupersub /\sub\i ln\i0 (1 + i)\nosupersub\par}";
        const string FORMULA_i = @"{\rtf1\ansi\ansicpg1252\deff0\deflang1046{\fonttbl{\f0\fnil\fcharset0 Calibri;}}\viewkind4\uc1\pard\sl276\slmult1\lang22\f0\fs22 i = (\super M\nosupersub /\sub C\nosupersub )\super 1/t \nosupersub - 1\par}";
        private NumberFormatInfo numberFormatInfo;

        public FrmCalculadora()
        {
            InitializeComponent();
            numberFormatInfo = NumberFormatInfo.GetInstance(CultureInfo.CurrentCulture);
            txtTaxa.TextChanged += txtTaxa_Change_Leave;
        }

        private void txtNumbersOnly_KeyPress(object sender, KeyPressEventArgs e)
        {
            var textBox = sender as TextBox;
            var nds = numberFormatInfo.NumberDecimalSeparator;
            if (e.KeyChar.ToString() == nds)
            {
                if (textBox.Text.Length == 0 || textBox.SelectedText.Length == textBox.Text.Length)
                {
                    textBox.Text = "0,";
                    textBox.SelectionStart = textBox.Text.Length;
                    e.Handled = true;
                }
                else if (textBox.Text.Contains(nds) && !textBox.SelectedText.Contains(nds))
                    e.Handled = true;
                return;
            }
            const string permitidos = "0123456789\b\u0003\u0016";
            e.Handled = !permitidos.Contains(e.KeyChar);
        }

        private void txtNumbersOnly_TextChanged(object sender, EventArgs e)
        {
            var textBox = sender as TextBox;
            var permitidos = "0123456789";
            var terminou = false;
            while (!terminou)
            {
                var qtdSeparadorDecimal = 0;
                terminou = true;
                for (int i = 0; i < textBox.Text.Length; i++)
                {
                    if (textBox.Text[i].ToString() == numberFormatInfo.NumberDecimalSeparator)
                    {
                        qtdSeparadorDecimal++;
                        if (qtdSeparadorDecimal > 1)
                        {
                            textBox.Text = textBox.Text.Remove(i, 1);
                            terminou = false;
                            break;
                        }
                    }
                    else if (!permitidos.Contains(textBox.Text[i]))
                    {
                        textBox.Text = textBox.Text.Remove(i, 1);
                        terminou = false;
                        break;
                    }
                }
            }
            ResetForm();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            Control txtResult = null;
            Func<double> formula = null;
            double M, C, i, t;
            ResetForm();

            switch (AvaliaFormulario(out M, out C, out i, out t))
            {
                case IncognitaFomula.Montante:
                    txtResult = txtMontante;
                    lblFormula.Rtf = FORMULA_M;
                    formula = () =>
                    {
                        M = C * Math.Pow(1 + (i / 100), t);
                        return M;
                    };
                    break;
                case IncognitaFomula.Capital:
                    txtResult = txtCapital;
                    lblFormula.Rtf = FORMULA_C;
                    formula = () =>
                    {
                        C = M / Math.Pow(1 + (i / 100), t);
                        return C;
                    };
                    break;
                case IncognitaFomula.Taxa:
                    txtResult = txtTaxa;
                    lblFormula.Rtf = FORMULA_i;
                    formula = () =>
                    {
                        i = (Math.Pow(M / C, 1 / t) - 1) * 100;
                        return i;
                    };
                    break;
                case IncognitaFomula.Tempo:
                    txtResult = txtTempo;
                    lblFormula.Rtf = FORMULA_t;
                    formula = () =>
                    {
                        t = (Math.Log10(M / C)) / (Math.Log10(1 + (i / 100)));
                        return t;
                    };
                    break;
                case IncognitaFomula.Nenhum:
                    lblFormula.Clear();
                    return;
                default: return;
            }
            txtResult.Text = formula().ToString();
            txtResult.Font = new Font(txtResult.Font, FontStyle.Bold);
            lblJuros.Text = (M - C).ToString();
            if (t > 1) CalculaProgressao(C, i, t);
        }

        private void txtTaxa_Change_Leave(object sender, EventArgs e)
        {
            string txt = "0";
            try
            {
                if (double.TryParse(txtTaxa.Text, out double taxa))
                {
                    txt = (taxa / 100).ToString();
                }
            }
            finally
            {
                lblTaxa.Text = txt;
            }
        }

        private void CalculaProgressao(double capital, double taxa, double tempo)
        {
            var ciclos = new Dictionary<int, double>();
            for (int ciclo = 1; ciclo <= tempo; ciclo++)
            {
                ciclos.Add(ciclo, capital * Math.Pow(1 + (taxa / 100), ciclo));
            }
            var screen = Screen.FromControl(this);
            chartLucro.Series[0].Points.DataBindXY(ciclos.Keys, ciclos.Values);
            Size = new Size(Size.Width, Size.Height + screen.Bounds.Height - Location.Y);
            chartLucro.ChartAreas[0].AxisY.LabelStyle.Format = "{0:C}";
            chartLucro.ChartAreas[0].AxisY.IsStartedFromZero = false;
            chartLucro.ChartAreas[0].AxisY.Minimum = ciclos[1];
            chartLucro.Visible = true;
        }

        private IncognitaFomula AvaliaFormulario(out double montante, out double capital, out double taxa, out double tempo)
        {
            var exMessage = "Preencha apenas três dos quatro campos.";
            var incognita = IncognitaFomula.Nenhum;
            Action<IncognitaFomula> setIncognita = (x) =>
            {
                if (incognita == IncognitaFomula.Nenhum)
                    incognita = x;
                else throw new Exception(exMessage);
            };
            Func<TextBox, double> doubleParse = (textBox) =>
             {
                 double result;
                 try
                 {
                     if (string.IsNullOrWhiteSpace(textBox.Text)
                      || textBox.Text.StartsWith(numberFormatInfo.NumberDecimalSeparator))
                         textBox.Text = "0" + textBox.Text;
                     result = double.Parse(textBox.Text);
                 }
                 catch
                 {
                     textBox.BackColor = Color.Red;
                     textBox.ForeColor = Color.White;
                     throw new Exception("Número inválido.");
                 }
                 return result;
             };
            montante = capital = tempo = taxa = 0;
            try
            {
                if ((montante = doubleParse(txtMontante)) == 0)
                    setIncognita(IncognitaFomula.Montante);
                if ((capital = doubleParse(txtCapital)) == 0)
                    setIncognita(IncognitaFomula.Capital);
                if ((taxa = doubleParse(txtTaxa)) == 0)
                    setIncognita(IncognitaFomula.Taxa);
                if ((tempo = doubleParse(txtTempo)) == 0)
                    setIncognita(IncognitaFomula.Tempo);
                if (montante != 0 && capital != 0 && taxa != 0 && tempo != 0)
                    throw new Exception(exMessage);
            }
            catch (Exception ex)
            {
                incognita = IncognitaFomula.Erro;
                lblMensagem.Text = ex.Message;
            }
            return incognita;
        }

        private void ResetForm()
        {
            lblMensagem.Text = string.Empty;
            foreach (Control ctrl in Controls)
            {
                TextBox textBox;
                if ((textBox = ctrl as TextBox) != null && !textBox.ReadOnly)
                {
                    textBox.BackColor = SystemColors.Window;
                    textBox.ForeColor = SystemColors.WindowText;
                    textBox.Font = new Font(textBox.Font, FontStyle.Regular);
                }
            }
        }
    }

    public enum IncognitaFomula
    {
        Nenhum, Montante, Capital, Tempo, Taxa, Erro
    }
}
