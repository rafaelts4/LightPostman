﻿namespace RestRequests
{
    partial class FrmProxySettings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmProxySettings));
            this.gpbProxy = new System.Windows.Forms.GroupBox();
            this.gbpCredentials = new System.Windows.Forms.GroupBox();
            this.txtProxyPassword = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtProxyUser = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.chkUseDefaultCredentials = new System.Windows.Forms.CheckBox();
            this.chkBypassOnLocal = new System.Windows.Forms.CheckBox();
            this.txtProxyPort = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtProxyUrl = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.gpbServerAuthentication = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.txtServerPassword = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtServerUser = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.chkServerDefaultCredentials = new System.Windows.Forms.CheckBox();
            this.chkPreAuthenticate = new System.Windows.Forms.CheckBox();
            this.chkNeedServerAuthentication = new System.Windows.Forms.CheckBox();
            this.gpbProxy.SuspendLayout();
            this.gbpCredentials.SuspendLayout();
            this.gpbServerAuthentication.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // gpbProxy
            // 
            this.gpbProxy.Controls.Add(this.gbpCredentials);
            this.gpbProxy.Controls.Add(this.chkUseDefaultCredentials);
            this.gpbProxy.Controls.Add(this.chkBypassOnLocal);
            this.gpbProxy.Controls.Add(this.txtProxyPort);
            this.gpbProxy.Controls.Add(this.label2);
            this.gpbProxy.Controls.Add(this.txtProxyUrl);
            this.gpbProxy.Controls.Add(this.label1);
            this.gpbProxy.Location = new System.Drawing.Point(12, 12);
            this.gpbProxy.Name = "gpbProxy";
            this.gpbProxy.Size = new System.Drawing.Size(283, 171);
            this.gpbProxy.TabIndex = 0;
            this.gpbProxy.TabStop = false;
            this.gpbProxy.Text = "Proxy";
            // 
            // gbpCredentials
            // 
            this.gbpCredentials.Controls.Add(this.txtProxyPassword);
            this.gbpCredentials.Controls.Add(this.label3);
            this.gbpCredentials.Controls.Add(this.txtProxyUser);
            this.gbpCredentials.Controls.Add(this.label4);
            this.gbpCredentials.Location = new System.Drawing.Point(10, 79);
            this.gbpCredentials.Name = "gbpCredentials";
            this.gbpCredentials.Size = new System.Drawing.Size(259, 81);
            this.gbpCredentials.TabIndex = 7;
            this.gbpCredentials.TabStop = false;
            this.gbpCredentials.Text = "Credentials";
            // 
            // txtProxyPassword
            // 
            this.txtProxyPassword.Location = new System.Drawing.Point(69, 49);
            this.txtProxyPassword.Name = "txtProxyPassword";
            this.txtProxyPassword.PasswordChar = '•';
            this.txtProxyPassword.Size = new System.Drawing.Size(173, 20);
            this.txtProxyPassword.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 56);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Password:";
            // 
            // txtProxyUser
            // 
            this.txtProxyUser.Location = new System.Drawing.Point(69, 18);
            this.txtProxyUser.Name = "txtProxyUser";
            this.txtProxyUser.Size = new System.Drawing.Size(173, 20);
            this.txtProxyUser.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(8, 25);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(32, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "User:";
            // 
            // chkUseDefaultCredentials
            // 
            this.chkUseDefaultCredentials.AutoSize = true;
            this.chkUseDefaultCredentials.Location = new System.Drawing.Point(134, 56);
            this.chkUseDefaultCredentials.Name = "chkUseDefaultCredentials";
            this.chkUseDefaultCredentials.Size = new System.Drawing.Size(134, 17);
            this.chkUseDefaultCredentials.TabIndex = 5;
            this.chkUseDefaultCredentials.Text = "Use default credentials";
            this.chkUseDefaultCredentials.UseVisualStyleBackColor = true;
            // 
            // chkBypassOnLocal
            // 
            this.chkBypassOnLocal.AutoSize = true;
            this.chkBypassOnLocal.Location = new System.Drawing.Point(20, 56);
            this.chkBypassOnLocal.Name = "chkBypassOnLocal";
            this.chkBypassOnLocal.Size = new System.Drawing.Size(100, 17);
            this.chkBypassOnLocal.TabIndex = 4;
            this.chkBypassOnLocal.Text = "Bypass on local";
            this.chkBypassOnLocal.UseVisualStyleBackColor = true;
            // 
            // txtProxyPort
            // 
            this.txtProxyPort.Location = new System.Drawing.Point(238, 21);
            this.txtProxyPort.Name = "txtProxyPort";
            this.txtProxyPort.Size = new System.Drawing.Size(30, 20);
            this.txtProxyPort.TabIndex = 3;
            this.txtProxyPort.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPort_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(209, 24);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Port:";
            // 
            // txtProxyUrl
            // 
            this.txtProxyUrl.Location = new System.Drawing.Point(36, 21);
            this.txtProxyUrl.Name = "txtProxyUrl";
            this.txtProxyUrl.Size = new System.Drawing.Size(167, 20);
            this.txtProxyUrl.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(23, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Url:";
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(224, 364);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 7;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // gpbServerAuthentication
            // 
            this.gpbServerAuthentication.Controls.Add(this.groupBox4);
            this.gpbServerAuthentication.Controls.Add(this.chkServerDefaultCredentials);
            this.gpbServerAuthentication.Controls.Add(this.chkPreAuthenticate);
            this.gpbServerAuthentication.Enabled = false;
            this.gpbServerAuthentication.Location = new System.Drawing.Point(12, 195);
            this.gpbServerAuthentication.Name = "gpbServerAuthentication";
            this.gpbServerAuthentication.Size = new System.Drawing.Size(283, 162);
            this.gpbServerAuthentication.TabIndex = 8;
            this.gpbServerAuthentication.TabStop = false;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.txtServerPassword);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Controls.Add(this.txtServerUser);
            this.groupBox4.Controls.Add(this.label6);
            this.groupBox4.Location = new System.Drawing.Point(10, 66);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(259, 81);
            this.groupBox4.TabIndex = 7;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Credentials";
            // 
            // txtServerPassword
            // 
            this.txtServerPassword.Location = new System.Drawing.Point(69, 49);
            this.txtServerPassword.Name = "txtServerPassword";
            this.txtServerPassword.PasswordChar = '•';
            this.txtServerPassword.Size = new System.Drawing.Size(173, 20);
            this.txtServerPassword.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(7, 56);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 13);
            this.label5.TabIndex = 2;
            this.label5.Text = "Password:";
            // 
            // txtServerUser
            // 
            this.txtServerUser.Location = new System.Drawing.Point(69, 18);
            this.txtServerUser.Name = "txtServerUser";
            this.txtServerUser.Size = new System.Drawing.Size(173, 20);
            this.txtServerUser.TabIndex = 1;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(8, 25);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(32, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "User:";
            // 
            // chkServerDefaultCredentials
            // 
            this.chkServerDefaultCredentials.AutoSize = true;
            this.chkServerDefaultCredentials.Location = new System.Drawing.Point(12, 43);
            this.chkServerDefaultCredentials.Name = "chkServerDefaultCredentials";
            this.chkServerDefaultCredentials.Size = new System.Drawing.Size(134, 17);
            this.chkServerDefaultCredentials.TabIndex = 5;
            this.chkServerDefaultCredentials.Text = "Use default credentials";
            this.chkServerDefaultCredentials.UseVisualStyleBackColor = true;
            // 
            // chkPreAuthenticate
            // 
            this.chkPreAuthenticate.AutoSize = true;
            this.chkPreAuthenticate.Location = new System.Drawing.Point(12, 20);
            this.chkPreAuthenticate.Name = "chkPreAuthenticate";
            this.chkPreAuthenticate.Size = new System.Drawing.Size(104, 17);
            this.chkPreAuthenticate.TabIndex = 4;
            this.chkPreAuthenticate.Text = "Pre authenticate";
            this.chkPreAuthenticate.UseVisualStyleBackColor = true;
            // 
            // chkNeedServerAuthentication
            // 
            this.chkNeedServerAuthentication.AutoSize = true;
            this.chkNeedServerAuthentication.Location = new System.Drawing.Point(24, 193);
            this.chkNeedServerAuthentication.Name = "chkNeedServerAuthentication";
            this.chkNeedServerAuthentication.Size = new System.Drawing.Size(157, 17);
            this.chkNeedServerAuthentication.TabIndex = 9;
            this.chkNeedServerAuthentication.Text = "Need Server Authentication";
            this.chkNeedServerAuthentication.UseVisualStyleBackColor = true;
            this.chkNeedServerAuthentication.CheckedChanged += new System.EventHandler(this.chkNeedServerAuthentication_CheckedChanged);
            // 
            // FrmProxySettings
            // 
            this.AcceptButton = this.btnSave;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(311, 392);
            this.Controls.Add(this.chkNeedServerAuthentication);
            this.Controls.Add(this.gpbServerAuthentication);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.gpbProxy);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmProxySettings";
            this.Text = "FrmProxySettings";
            this.Load += new System.EventHandler(this.FrmProxySettings_Load);
            this.gpbProxy.ResumeLayout(false);
            this.gpbProxy.PerformLayout();
            this.gbpCredentials.ResumeLayout(false);
            this.gbpCredentials.PerformLayout();
            this.gpbServerAuthentication.ResumeLayout(false);
            this.gpbServerAuthentication.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gpbProxy;
        private System.Windows.Forms.TextBox txtProxyPort;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtProxyUrl;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox chkBypassOnLocal;
        private System.Windows.Forms.CheckBox chkUseDefaultCredentials;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.GroupBox gbpCredentials;
        private System.Windows.Forms.TextBox txtProxyPassword;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtProxyUser;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox gpbServerAuthentication;
        private System.Windows.Forms.CheckBox chkNeedServerAuthentication;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox txtServerPassword;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtServerUser;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.CheckBox chkServerDefaultCredentials;
        private System.Windows.Forms.CheckBox chkPreAuthenticate;
    }
}