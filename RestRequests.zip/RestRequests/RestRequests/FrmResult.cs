﻿using Newtonsoft.Json;
using System;
using System.Drawing;
using System.Net;
using System.Net.Http;
using System.Windows.Forms;

namespace RestRequests
{
    public partial class FrmResult : Form
    {                
        private HttpRequestMessage httpRequest;

        public FrmResult()
        {
            InitializeComponent();
            setLayout();
            jsonTreeView.NodeMouseClick += jsonTreeView_NodeMouseClick;
            Properties.Settings.Default.PropertyChanged += default_PropertyChanged;            
        }

        private FrmResult(bool allowUserInput): this()
        {
            txtResult.ReadOnly = !allowUserInput;
            txtResult.BackColor = allowUserInput
                ? SystemColors.Window
                : SystemColors.Control;
            splitContainer.Panel1.Enabled = allowUserInput;
        }

        public FrmResult(string rawText) : this(true)
        {
            txtResult.Text = rawText;                        
        }

        public FrmResult(string caption, HttpRequestMessage request) : this(false)
        {
            Text = caption;
            httpRequest = request;
        }

        private async void frmResult_Shown(object sender, EventArgs e)
        {
            if (httpRequest == null)
                return;
            HttpResponseMessage response;
            try
            {
                progressBar.Show();
                try
                {
                    var httpClient = CreateHttpClient();
                    response = await httpClient.SendAsync(httpRequest);
                    writeHttpResult(response);
                }
                catch (Exception ex)
                {
                    PrintException(ex, txtResult);
                    return;
                }
                try
                {
                    txtResult.Text = await response.Content.ReadAsStringAsync();
                    splitContainer.Panel1.Enabled = true;
                    string contentType = response.Content.Headers.ContentType?.MediaType?.ToLower();
                    if (contentType?.Contains("application/json") == true)
                        rdbJson.Checked = true;
                    else if (contentType?.Contains("text/html") == true)
                        rdbHtml.Checked = true;                    
                }
                catch (Exception ex)
                {
                    PrintException(ex, txtResult);
                }
            }
            finally
            {                
                progressBar.Hide();
            }
        }

        private void writeHttpResult(HttpResponseMessage response)
        {
            lblHttpResult.Text = $"{(int)response.StatusCode}: {response.ReasonPhrase}";
            lblHttpResult.ForeColor = (response.IsSuccessStatusCode) ? Color.Green : Color.Red;
            var location = lblHttpResult.Location;
            location.X -= lblHttpResult.Size.Width;
            lblHttpResult.Location = location;
        }

        private void default_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == SettingsController.LayoutSettingsName)
                setLayout();
        }

        private void rdbRaw_CheckedChanged(object sender, EventArgs e)
        {            
            txtResult.Visible = true;
            jsonTreeView.Visible = false;
            webBrowser.Visible = false;
        }

        private void rdbJson_CheckedChanged(object sender, EventArgs e)
        {
            if (!rdbJson.Checked)
                return;
            try
            {
                var jsonObject = JsonConvert.DeserializeObject(txtResult.Text);
                var identedJson = JsonConvert.SerializeObject(jsonObject, Formatting.Indented);
                txtResult.Text = identedJson;
                txtResult.Visible = true;
                jsonTreeView.Visible = false;
                webBrowser.Visible = false;
            }
            catch
            {
                rdbRaw.Checked = true;
                MessageBox.Show("Content is not in correct format.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void rdbJTree_CheckedChanged(object sender, EventArgs e)
        {
            if (!rdbJTree.Checked)
                return;
            try
            {
                jsonTreeView.ShowJson(txtResult.Text);
                txtResult.Visible = false;
                webBrowser.Visible = false;
                jsonTreeView.Visible = true;
                jsonTreeView.ExpandAll();
            }
            catch
            {
                rdbRaw.Checked = true;
                MessageBox.Show("Content is not in correct format.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void rdbHtml_CheckedChanged(object sender, EventArgs e)
        {
            if (!rdbHtml.Checked)
                return;
            try
            {
                txtResult.Visible = false;
                jsonTreeView.Visible = false;
                webBrowser.DocumentText = txtResult.Text;
                webBrowser.Visible = true;
            }
            catch
            {
                rdbRaw.Checked = true;
                MessageBox.Show("Content is not in correct format.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void setLayout()
        {
            txtResult.ForeColor = SettingsController.LayoutSettings.ForeColor;
            txtResult.Font = SettingsController.LayoutSettings.Font;
        }

        protected void PrintException(Exception ex, Control ctrl)
        {
            ctrl.ForeColor = Color.Red;
            ctrl.Text = ex.Message;
            var innerException = ex.InnerException;
            while (innerException != null)
            {
                ctrl.Text += Environment.NewLine;
                ctrl.Text += innerException.Message;
                innerException = innerException.InnerException;
            }
        }

        protected HttpClient CreateHttpClient()
        {
            ProxySettingsModel proxySettings = SettingsController.ProxySettings;
            if (string.IsNullOrWhiteSpace(proxySettings?.Uri) || proxySettings.Port == 0)
                return new HttpClient();
            // First create a proxy object
            var webProxy = new WebProxy
            {
                Address = new Uri($"{proxySettings.Uri}:{proxySettings.Port}"),
                BypassProxyOnLocal = proxySettings.BypassyOnLocal,
                UseDefaultCredentials = proxySettings.Credentials.UseDefaultCredentials
            };

            // *** These creds are given to the proxy server, not the web server ***
            if (!string.IsNullOrWhiteSpace(proxySettings.Credentials?.UserName))
            {
                webProxy.Credentials = new NetworkCredential(
                    userName: proxySettings.Credentials.UserName,
                    password: proxySettings.Credentials.Password);
            }

            // Now create a client handler which uses that proxy
            var httpClientHandler = new HttpClientHandler
            {
                Proxy = webProxy,
            };

            // Omit this part if you don't need to authenticate with the web server:
            if (proxySettings.NeedServerAuthentication)
            {
                httpClientHandler.PreAuthenticate = true;
                httpClientHandler.UseDefaultCredentials = false;

                // *** These creds are given to the web server, not the proxy server ***
                httpClientHandler.Credentials = new NetworkCredential(
                    userName: proxySettings.ServerCredentials.UserName,
                    password: proxySettings.ServerCredentials.Password);
            }

            // Finally, create the HTTP client object
            var httpClient = new HttpClient(handler: httpClientHandler, disposeHandler: true);
            return httpClient;
        }
      
        private void jsonTreeView_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            var txt = e.Node.Text;
            try
            {
                int idx = txt.IndexOf(":");
                if (idx > -1)
                    txt = txt.Substring(idx + 1).Trim();
                idx = txt.IndexOf(" (type: ");
                if (idx > -1)
                    txt = txt.Substring(0, idx).Trim();
            }
            finally
            {
                if (!string.IsNullOrWhiteSpace(txt))
                    Clipboard.SetText(txt);
            }
        }
    }
}