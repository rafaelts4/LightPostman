﻿namespace RestRequests
{
    partial class FrmWebRequest
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmWebRequest));
            this.lblHttpResult = new System.Windows.Forms.Label();
            this.jsonTreeView = new Alex75.JsonViewer.WindowsForm.JsonTreeView();
            this.splitContainer = new System.Windows.Forms.SplitContainer();
            this.btnSend = new System.Windows.Forms.Button();
            this.cboMethod = new System.Windows.Forms.ComboBox();
            this.txtUrl = new System.Windows.Forms.TextBox();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.cboEncoding = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtContent = new System.Windows.Forms.TextBox();
            this.cboContentType = new System.Windows.Forms.ComboBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.txtAuthorization = new System.Windows.Forms.TextBox();
            this.cboAuthorizationType = new System.Windows.Forms.ComboBox();
            this.lblAuthorizationType = new System.Windows.Forms.Label();
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.proxyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.layoutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.interestToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.convertToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.promptToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).BeginInit();
            this.splitContainer.Panel1.SuspendLayout();
            this.splitContainer.Panel2.SuspendLayout();
            this.splitContainer.SuspendLayout();
            this.tabControl.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.menuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblHttpResult
            // 
            this.lblHttpResult.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblHttpResult.AutoSize = true;
            this.lblHttpResult.Location = new System.Drawing.Point(71, 5);
            this.lblHttpResult.Name = "lblHttpResult";
            this.lblHttpResult.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblHttpResult.Size = new System.Drawing.Size(0, 13);
            this.lblHttpResult.TabIndex = 4;
            // 
            // jsonTreeView
            // 
            this.jsonTreeView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.jsonTreeView.FullRowSelect = true;
            this.jsonTreeView.ImageIndex = 0;
            this.jsonTreeView.LineColor = System.Drawing.Color.Empty;
            this.jsonTreeView.Location = new System.Drawing.Point(0, 0);
            this.jsonTreeView.Margin = new System.Windows.Forms.Padding(2);
            this.jsonTreeView.Name = "jsonTreeView";
            this.jsonTreeView.SelectedImageIndex = 0;
            this.jsonTreeView.Size = new System.Drawing.Size(479, 328);
            this.jsonTreeView.TabIndex = 9;
            this.jsonTreeView.Visible = false;
            // 
            // splitContainer
            // 
            this.splitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer.IsSplitterFixed = true;
            this.splitContainer.Location = new System.Drawing.Point(0, 24);
            this.splitContainer.Name = "splitContainer";
            this.splitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer.Panel1
            // 
            this.splitContainer.Panel1.Controls.Add(this.btnSend);
            this.splitContainer.Panel1.Controls.Add(this.cboMethod);
            this.splitContainer.Panel1.Controls.Add(this.txtUrl);
            // 
            // splitContainer.Panel2
            // 
            this.splitContainer.Panel2.Controls.Add(this.tabControl);
            this.splitContainer.Panel2.Controls.Add(this.lblHttpResult);
            this.splitContainer.Panel2.Controls.Add(this.jsonTreeView);
            this.splitContainer.Size = new System.Drawing.Size(479, 373);
            this.splitContainer.SplitterDistance = 38;
            this.splitContainer.SplitterWidth = 1;
            this.splitContainer.TabIndex = 9;
            // 
            // btnSend
            // 
            this.btnSend.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSend.Location = new System.Drawing.Point(407, 6);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(64, 23);
            this.btnSend.TabIndex = 11;
            this.btnSend.Text = "Send";
            this.btnSend.UseVisualStyleBackColor = true;
            this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
            // 
            // cboMethod
            // 
            this.cboMethod.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Append;
            this.cboMethod.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cboMethod.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboMethod.FormattingEnabled = true;
            this.cboMethod.Items.AddRange(new object[] {
            "POST",
            "GET",
            "PUT",
            "DELETE",
            "OPTIONS"});
            this.cboMethod.Location = new System.Drawing.Point(7, 7);
            this.cboMethod.Name = "cboMethod";
            this.cboMethod.Size = new System.Drawing.Size(79, 21);
            this.cboMethod.TabIndex = 10;
            // 
            // txtUrl
            // 
            this.txtUrl.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtUrl.Location = new System.Drawing.Point(89, 7);
            this.txtUrl.Name = "txtUrl";
            this.txtUrl.Size = new System.Drawing.Size(315, 20);
            this.txtUrl.TabIndex = 9;
            this.txtUrl.Text = "https://rt1-auc-ns1-d.apps.ops-hmg.crefisa.com.br/Autenticacao";
            this.txtUrl.Leave += new System.EventHandler(this.txtUrl_Leave);
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tabPage1);
            this.tabControl.Controls.Add(this.tabPage2);
            this.tabControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl.Location = new System.Drawing.Point(0, 0);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(479, 334);
            this.tabControl.TabIndex = 10;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.cboEncoding);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.txtContent);
            this.tabPage1.Controls.Add(this.cboContentType);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(471, 308);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Body";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // cboEncoding
            // 
            this.cboEncoding.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cboEncoding.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Append;
            this.cboEncoding.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cboEncoding.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboEncoding.FormattingEnabled = true;
            this.cboEncoding.Items.AddRange(new object[] {
            "UTF-8",
            "ANSI",
            "UTF-7",
            "UTF-16 Big Endian",
            "UTF-16 Little Endian",
            "UTF-32",
            "ACII"});
            this.cboEncoding.Location = new System.Drawing.Point(337, 6);
            this.cboEncoding.Name = "cboEncoding";
            this.cboEncoding.Size = new System.Drawing.Size(130, 21);
            this.cboEncoding.TabIndex = 12;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 13);
            this.label1.TabIndex = 13;
            this.label1.Text = "Content Type:";
            // 
            // txtContent
            // 
            this.txtContent.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtContent.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtContent.Location = new System.Drawing.Point(3, 33);
            this.txtContent.MaxLength = 2147483647;
            this.txtContent.Multiline = true;
            this.txtContent.Name = "txtContent";
            this.txtContent.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtContent.Size = new System.Drawing.Size(465, 272);
            this.txtContent.TabIndex = 12;
            this.txtContent.Text = "{\r\n    \"User\": \"USR_CTN_JWT\",\r\n    \"Pass\": \"Mudar123\",\r\n    \"Application\": \"User\"" +
    "\r\n}";
            // 
            // cboContentType
            // 
            this.cboContentType.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cboContentType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Append;
            this.cboContentType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cboContentType.FormattingEnabled = true;
            this.cboContentType.Items.AddRange(new object[] {
            "application/json",
            "application/x-www-form-urlencoded",
            "text/plain",
            "text/html",
            "multipart/form-data",
            "application/jar",
            "image/png",
            "image/gif",
            "audio/mp3"});
            this.cboContentType.Location = new System.Drawing.Point(88, 6);
            this.cboContentType.Name = "cboContentType";
            this.cboContentType.Size = new System.Drawing.Size(243, 21);
            this.cboContentType.TabIndex = 11;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.txtAuthorization);
            this.tabPage2.Controls.Add(this.cboAuthorizationType);
            this.tabPage2.Controls.Add(this.lblAuthorizationType);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(471, 308);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Auth";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // txtAuthorization
            // 
            this.txtAuthorization.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtAuthorization.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAuthorization.Location = new System.Drawing.Point(3, 36);
            this.txtAuthorization.Multiline = true;
            this.txtAuthorization.Name = "txtAuthorization";
            this.txtAuthorization.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtAuthorization.Size = new System.Drawing.Size(465, 269);
            this.txtAuthorization.TabIndex = 16;
            // 
            // cboAuthorizationType
            // 
            this.cboAuthorizationType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Append;
            this.cboAuthorizationType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cboAuthorizationType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboAuthorizationType.FormattingEnabled = true;
            this.cboAuthorizationType.Items.AddRange(new object[] {
            "No Auth",
            "Bearer Token"});
            this.cboAuthorizationType.Location = new System.Drawing.Point(44, 6);
            this.cboAuthorizationType.Name = "cboAuthorizationType";
            this.cboAuthorizationType.Size = new System.Drawing.Size(130, 21);
            this.cboAuthorizationType.TabIndex = 14;
            // 
            // lblAuthorizationType
            // 
            this.lblAuthorizationType.AutoSize = true;
            this.lblAuthorizationType.Location = new System.Drawing.Point(4, 10);
            this.lblAuthorizationType.Name = "lblAuthorizationType";
            this.lblAuthorizationType.Size = new System.Drawing.Size(34, 13);
            this.lblAuthorizationType.TabIndex = 15;
            this.lblAuthorizationType.Text = "Type:";
            // 
            // menuStrip
            // 
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.viewToolStripMenuItem,
            this.interestToolStripMenuItem,
            this.convertToolStripMenuItem,
            this.promptToolStripMenuItem});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Size = new System.Drawing.Size(479, 24);
            this.menuStrip.TabIndex = 10;
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.BackColor = System.Drawing.SystemColors.Control;
            this.toolStripMenuItem1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.proxyToolStripMenuItem,
            this.layoutToolStripMenuItem});
            this.toolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripMenuItem1.Image")));
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(73, 20);
            this.toolStripMenuItem1.Text = "Setings";
            // 
            // proxyToolStripMenuItem
            // 
            this.proxyToolStripMenuItem.Name = "proxyToolStripMenuItem";
            this.proxyToolStripMenuItem.Size = new System.Drawing.Size(110, 22);
            this.proxyToolStripMenuItem.Text = "Proxy";
            this.proxyToolStripMenuItem.Click += new System.EventHandler(this.proxyToolStripMenuItem_Click);
            // 
            // layoutToolStripMenuItem
            // 
            this.layoutToolStripMenuItem.Name = "layoutToolStripMenuItem";
            this.layoutToolStripMenuItem.Size = new System.Drawing.Size(110, 22);
            this.layoutToolStripMenuItem.Text = "Layout";
            this.layoutToolStripMenuItem.Click += new System.EventHandler(this.layoutToolStripMenuItem_Click);
            // 
            // viewToolStripMenuItem
            // 
            this.viewToolStripMenuItem.Image = global::RestRequests.Properties.Resources.vision;
            this.viewToolStripMenuItem.Name = "viewToolStripMenuItem";
            this.viewToolStripMenuItem.Size = new System.Drawing.Size(64, 20);
            this.viewToolStripMenuItem.Text = "JView";
            this.viewToolStripMenuItem.MouseUp += new System.Windows.Forms.MouseEventHandler(this.viewToolStripMenuItem_MouseUp);
            // 
            // interestToolStripMenuItem
            // 
            this.interestToolStripMenuItem.Image = global::RestRequests.Properties.Resources.low;
            this.interestToolStripMenuItem.Name = "interestToolStripMenuItem";
            this.interestToolStripMenuItem.Size = new System.Drawing.Size(74, 20);
            this.interestToolStripMenuItem.Text = "Interest";
            this.interestToolStripMenuItem.MouseUp += new System.Windows.Forms.MouseEventHandler(this.interestToolStripMenuItem_MouseUp);
            // 
            // convertToolStripMenuItem
            // 
            this.convertToolStripMenuItem.Image = global::RestRequests.Properties.Resources.hash;
            this.convertToolStripMenuItem.Name = "convertToolStripMenuItem";
            this.convertToolStripMenuItem.Size = new System.Drawing.Size(77, 20);
            this.convertToolStripMenuItem.Text = "Convert";
            this.convertToolStripMenuItem.MouseUp += new System.Windows.Forms.MouseEventHandler(this.convertToolStripMenuItem_MouseUp);
            // 
            // promptToolStripMenuItem
            // 
            this.promptToolStripMenuItem.Image = global::RestRequests.Properties.Resources.command_prompt;
            this.promptToolStripMenuItem.Name = "promptToolStripMenuItem";
            this.promptToolStripMenuItem.Size = new System.Drawing.Size(75, 20);
            this.promptToolStripMenuItem.Text = "Prompt";
            this.promptToolStripMenuItem.MouseUp += new System.Windows.Forms.MouseEventHandler(this.promptToolStripMenuItem_MouseUp);
            // 
            // FrmWebRequest
            // 
            this.AcceptButton = this.btnSend;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(479, 397);
            this.Controls.Add(this.splitContainer);
            this.Controls.Add(this.menuStrip);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmWebRequest";
            this.Text = "Web Request";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FrmWebRequest_FormClosed);
            this.splitContainer.Panel1.ResumeLayout(false);
            this.splitContainer.Panel1.PerformLayout();
            this.splitContainer.Panel2.ResumeLayout(false);
            this.splitContainer.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).EndInit();
            this.splitContainer.ResumeLayout(false);
            this.tabControl.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblHttpResult;
        private Alex75.JsonViewer.WindowsForm.JsonTreeView jsonTreeView;
        private System.Windows.Forms.SplitContainer splitContainer;
        private System.Windows.Forms.Button btnSend;
        private System.Windows.Forms.ComboBox cboMethod;
        private System.Windows.Forms.TextBox txtUrl;
        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem proxyToolStripMenuItem;
        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.ComboBox cboContentType;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtContent;
        private System.Windows.Forms.ToolStripMenuItem layoutToolStripMenuItem;
        private System.Windows.Forms.ComboBox cboEncoding;
        private System.Windows.Forms.TextBox txtAuthorization;
        private System.Windows.Forms.ComboBox cboAuthorizationType;
        private System.Windows.Forms.Label lblAuthorizationType;
        private System.Windows.Forms.ToolStripMenuItem viewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem interestToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem convertToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem promptToolStripMenuItem;
    }
}

