﻿using System;
using System.Linq;
using System.Net.Http;
using System.Windows.Forms;
using System.Threading.Tasks;

namespace RestRequests
{
    using Microsoft.CSharp;
    using System.CodeDom.Compiler;
    using System.Collections.Generic;
    using System.Drawing;
    using System.IO;
    using System.Reflection;
    using System.ServiceModel;

    public partial class FrmResultSvc : Form
    {
        private string randomName;
        private HttpRequestMessage httpRequest;        

        public FrmResultSvc()
        {
            InitializeComponent();
            randomName = "_" + Guid.NewGuid();
        }

        public FrmResultSvc(string caption, HttpRequestMessage request) : this()
        {
            Text = caption;
            httpRequest = request;
        }

        private async void frmResult_Shown(object sender, EventArgs e)
        {
            try
            {
                var filePath = $"Temp\\{randomName}";
                //Baixa classes de referência basedo no wsdl.
                var processStartInfo = new System.Diagnostics.ProcessStartInfo()
                {
                    FileName = "svcutil.exe",
                    Arguments = $"{httpRequest.RequestUri} /t:Code /out:{filePath}.cs /config:{filePath}.config",                    
                    CreateNoWindow = true,
                    WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden
                };
                var process = System.Diagnostics.Process.Start(processStartInfo);
                await Task.Run(() => process.WaitForExit());

                //Cria assembly das classes de referência.
                var assemblyReferences = new string[9]
                { "mscorlib.dll"
                , "System.dll"
                , "System.Web.Services.dll"
                , "System.Web.dll"
                , "System.Xml.dll"
                , "System.Data.dll"
                , "System.ServiceModel.dll"
                , "System.ServiceModel.Primitives.dll"
                , "System.Runtime.Serialization.dll"};
                var compParms = new CompilerParameters(assemblyReferences)
                {
                    GenerateInMemory = true,
                    GenerateExecutable = false,
                    OutputAssembly = Path.Combine(Environment.CurrentDirectory, $"{filePath}.dll")
                };
                var csProvider = new CSharpCodeProvider();
                CompilerResults compilerResults = csProvider.CompileAssemblyFromSource(compParms, File.ReadAllText(filePath + ".cs"));

                //Carrega o assembly em memória para não travar o arquivo.
                byte[] bytes = File.ReadAllBytes($"{filePath}.dll");
                AppDomain.CurrentDomain.Load(bytes);

                //Apaga arquivos gerados.
                _ = Task.Run(() =>
                {
                    var exts = new string[] { "cs", "dll", "config" };
                    foreach (string ext in exts)
                    {
                        string fileToDelete = $"{filePath}.{ext}";
                        try
                        {
                            File.Delete(fileToDelete);                            
                        }
                        catch
                        {
                            System.Diagnostics.Debug.WriteLine($"Não foi possível apagar o arquivo {fileToDelete}.");
                            continue;
                        }
                    }
                });
                                
                //Extrai ClientServices e seus métodos do assembly criado.
                var wsAssembly = AppDomain.CurrentDomain.GetAssemblies().FirstOrDefault(dll => dll.FullName.Contains(randomName));
                if(wsAssembly == null)
                {
                    MessageBox.Show("Falha ao extrair cotrato de serviço.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Close();
                }
                foreach (var classType in wsAssembly.GetTypes())
                {
                    var methods = classType.GetMethods().Where(m =>
                        m.Name != "Open" && m.Name != "Close" && m.Name != "Abort" &&
                        m.Module.Name != "mscorlib.dll" &&
                        m.Attributes == (MethodAttributes.Public
                        | MethodAttributes.Final
                        | MethodAttributes.Virtual
                        | MethodAttributes.HideBySig
                        | MethodAttributes.NewSlot)
                    ).OrderBy(m => m.Name);
                    if (methods.Any())
                    {
                        var classNode = treeViewServices.Nodes.Add(classType.Name);
                        classNode.Tag = classType;
                        foreach (var method in methods)
                        {
                            if (method.ReturnType == typeof(Task)
                            || (method.ReturnType.IsGenericType && method.ReturnType.GetGenericTypeDefinition() == typeof(Task<>)))
                                continue;
                            var methodNode = classNode.Nodes.Add(method.Name);
                            methodNode.Tag = method;
                        }
                    }
                }

                treeViewServices.ExpandAll();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
            }
            finally
            {
                progressBar.Hide();
            }
        }

        private void treeViewServices_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            var methodInfo = treeViewServices.SelectedNode?.Tag as MethodInfo;
            if (methodInfo == null)
                return;

            lblMethod.Text = methodInfo.Name;

            var parametersInfo = methodInfo.GetParameters();

            pnlParameters.Controls.Clear();
            var refPoint = new Point(10, 10);
            pnlParameters.AutoScroll = false;
            foreach (ParameterInfo parameterInfo in parametersInfo)
            {
                CreateParameterInput(ref refPoint, parameterInfo.Name, parameterInfo.ParameterType);
            }
            pnlParameters.AutoScroll = true;
        }

        private void intValidateion_KeyPress(object sender, KeyPressEventArgs e)
        {
            const string permitidos = "0123456789-\b\u0003\u0016";
            e.Handled = !permitidos.Contains(e.KeyChar);
        }

        private void decimalValidateion_KeyPress(object sender, KeyPressEventArgs e)
        {
            string permitidos = "0123456789-.,\b\u0003\u0016";
            e.Handled = !permitidos.Contains(e.KeyChar);
        }

        private async void btnInvoke_Click(object sender, EventArgs e)
        {
            var methodInfo = treeViewServices.SelectedNode?.Tag as MethodInfo;
            if (methodInfo == null)
                return;
            var classType = treeViewServices.SelectedNode.Parent?.Tag as Type;
            if (classType == null)
                return;
            progressBar.Show();
            try
            {
                var parametersInfo = methodInfo.GetParameters();
                List<object> parameterValues = parametersInfo.Length > 0
                    ? new List<object>()
                    : null;

                foreach (var parameterInfo in parametersInfo)
                {
                    parameterValues.Add(GetParameterValue(parameterInfo.Name, parameterInfo.ParameterType));
                }
                var json = await ExecuteWithReflection(classType, methodInfo, parameterValues?.ToArray());
                new FrmResult(json).Show();
            }
            finally
            {
                progressBar.Hide();
            }
        }

        private object GetParameterValue(string parameterName, Type parameterType)
        {
            object valueToReturn = null;
            if (parameterType.IsSimple())
            {
                var controls = pnlParameters.Controls.Cast<Control>();
                var txtValue = controls.FirstOrDefault(ctrl =>
                    (ctrl.Tag as Tuple<string, Type>)?.Item1 == parameterName
                )?.Text;
                try
                {
                    valueToReturn = parameterType.ChangeType(txtValue);
                }
                catch
                {
                    var msg = $"Não foi possível converter o valor \"{txtValue}\" para o tipo {parameterType.Name}.";
                    MessageBox.Show(msg, "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else if (parameterType.IsArray)
            {
                var controls = pnlParameters.Controls.Cast<Control>();
                var textsArrays = controls.FirstOrDefault(ctrl =>
                    (ctrl.Tag as Tuple<string, Type>)?.Item1 == parameterName
                )?.Text.Split(new char[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
                try
                {
                    var array = Array.CreateInstance(parameterType.GetElementType(), textsArrays.Length);
                    for (int i = 0; i < textsArrays.Length; i++)
                    {
                        var convertedValue = parameterType.GetElementType().ChangeType(textsArrays[i]?.TrimEnd());
                        array.SetValue(convertedValue, i);
                    }
                    valueToReturn = array;
                }
                catch
                {
                    var msg = $"Valor informado para o parâmetro {parameterName} não é do tipo {parameterType.Name}.";
                    MessageBox.Show(msg, "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            else
            {
                if (parameterType.GetConstructors().Length == 0)
                    return null;
                var instance = Activator.CreateInstance(parameterType);
                var propertiesInfo = parameterType.GetProperties().Where(p => p.CanRead && p.CanWrite);
                foreach (var propInfo in propertiesInfo)
                {
                    valueToReturn = GetParameterValue(propInfo.Name, propInfo.PropertyType);
                    propInfo.SetValue(instance, valueToReturn);
                }
                valueToReturn = instance;
            }
            return valueToReturn;
        }

        private void CreateParameterInput(ref Point refPoint, string parameterName, Type type)
        {
            var label = new Label()
            {
                Text = parameterName,
                AutoEllipsis = false,
                Location = new Point(refPoint.X, refPoint.Y + 2),
                Anchor = AnchorStyles.Top | AnchorStyles.Left,
                Font = new Font(Font, type.IsSimple() || type.IsArray
                    ? FontStyle.Regular
                    : FontStyle.Bold),
                AutoSize = true
            };
            label.MouseHover += (sender, arg) =>
            {
                var point = PointToClient(Cursor.Position);
                toolTipParamType.Show(type.Name, this, point.X, point.Y, 1500);
            };
            pnlParameters.Controls.Add(label);
            if (type.IsSimple())
            {
                label.Text += ": ";
                var textBox = new TextBox()
                {
                    Location = new Point(+label.Location.X + label.Width + 5, refPoint.Y),
                    Size = new Size(pnlParameters.Width - (label.Location.X + label.Width + 10), 45),
                    Anchor = AnchorStyles.Top | AnchorStyles.Right | AnchorStyles.Left,
                    Tag = new Tuple<string, Type>(parameterName, type)
                };
                if (type.IsInteger())
                    textBox.KeyPress += intValidateion_KeyPress;
                else if (type.IsDecimal())
                    textBox.KeyPress += decimalValidateion_KeyPress;
                pnlParameters.Controls.Add(textBox);
                refPoint.Y += 25;
            }
            else if (type.IsArray)
            {
                label.Text += ": ";
                var multiline = new TextBox()
                {
                    Multiline = true,
                    Location = new Point(+label.Location.X + label.Width + 5, refPoint.Y),
                    Size = new Size(pnlParameters.Width - (label.Location.X + label.Width + 10), 45),
                    Anchor = AnchorStyles.Top | AnchorStyles.Right | AnchorStyles.Left,
                    Tag = new Tuple<string, Type>(parameterName, type)
                };
                if (type.IsInteger())
                    multiline.KeyPress += intValidateion_KeyPress;
                else if (type.IsDecimal())
                    multiline.KeyPress += decimalValidateion_KeyPress;
                pnlParameters.Controls.Add(multiline);
                refPoint.Y += 45;
            }
            else
            {
                refPoint.Y += 25;
                refPoint.X += 05;
                var properties = type.GetProperties().Where(p => p.CanRead && p.CanWrite);
                foreach (PropertyInfo innerProperty in properties)
                {
                    if (innerProperty.PropertyType == type)
                        continue;
                    var underlyingType = Nullable.GetUnderlyingType(innerProperty.PropertyType);
                    if (underlyingType == null)
                        CreateParameterInput(ref refPoint, innerProperty.Name, innerProperty.PropertyType);
                    else
                    {
                        CreateParameterInput(ref refPoint, innerProperty.Name, underlyingType);
                    }
                }
                refPoint.X -= 5;
            }
        }

        private async Task<string> ExecuteWithReflection(Type typeInstance, MethodInfo methodInfo, object[] parameterObject = null)
        {
            object result = null;
            try
            {
                if (typeInstance != null && methodInfo != null)
                {
                    string url = httpRequest.RequestUri.ToString();
                    var args = new object[] {
                        new BasicHttpBinding(),
                        new EndpointAddress(url)
                    };
                    var classInstance = Activator.CreateInstance(typeInstance, args);
                    result = await Task.Run(() => methodInfo.Invoke(classInstance, parameterObject));
                }
            }
            catch (Exception ex)
            {
                var msg = string.Empty;
                var innerEx = ex;
                while (innerEx != null)
                {
                    msg += innerEx.Message + Environment.NewLine;
                    innerEx = innerEx.InnerException;
                }
                result = new { Message = msg.Trim() };
            }
            return Newtonsoft.Json.JsonConvert.SerializeObject(result);
        }
    }
}