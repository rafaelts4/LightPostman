﻿namespace RestRequests
{
    partial class FrmResult
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmResult));
            this.lblHttpResult = new System.Windows.Forms.Label();
            this.jsonTreeView = new Alex75.JsonViewer.WindowsForm.JsonTreeView();
            this.splitContainer = new System.Windows.Forms.SplitContainer();
            this.rdbHtml = new System.Windows.Forms.RadioButton();
            this.progressBar = new System.Windows.Forms.ProgressBar();
            this.lblVisualization = new System.Windows.Forms.Label();
            this.rdbJTree = new System.Windows.Forms.RadioButton();
            this.rdbJson = new System.Windows.Forms.RadioButton();
            this.rdbRaw = new System.Windows.Forms.RadioButton();
            this.webBrowser = new System.Windows.Forms.WebBrowser();
            this.txtResult = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).BeginInit();
            this.splitContainer.Panel1.SuspendLayout();
            this.splitContainer.Panel2.SuspendLayout();
            this.splitContainer.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblHttpResult
            // 
            this.lblHttpResult.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblHttpResult.AutoSize = true;
            this.lblHttpResult.Location = new System.Drawing.Point(470, 6);
            this.lblHttpResult.Name = "lblHttpResult";
            this.lblHttpResult.Size = new System.Drawing.Size(0, 13);
            this.lblHttpResult.TabIndex = 4;
            // 
            // jsonTreeView
            // 
            this.jsonTreeView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.jsonTreeView.FullRowSelect = true;
            this.jsonTreeView.ImageIndex = 0;
            this.jsonTreeView.LineColor = System.Drawing.Color.Empty;
            this.jsonTreeView.Location = new System.Drawing.Point(0, 0);
            this.jsonTreeView.Margin = new System.Windows.Forms.Padding(2);
            this.jsonTreeView.Name = "jsonTreeView";
            this.jsonTreeView.SelectedImageIndex = 0;
            this.jsonTreeView.Size = new System.Drawing.Size(479, 328);
            this.jsonTreeView.TabIndex = 9;
            this.jsonTreeView.Visible = false;
            // 
            // splitContainer
            // 
            this.splitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer.IsSplitterFixed = true;
            this.splitContainer.Location = new System.Drawing.Point(0, 0);
            this.splitContainer.Name = "splitContainer";
            this.splitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer.Panel1
            // 
            this.splitContainer.Panel1.Controls.Add(this.rdbHtml);
            this.splitContainer.Panel1.Controls.Add(this.progressBar);
            this.splitContainer.Panel1.Controls.Add(this.lblVisualization);
            this.splitContainer.Panel1.Controls.Add(this.rdbJTree);
            this.splitContainer.Panel1.Controls.Add(this.rdbJson);
            this.splitContainer.Panel1.Controls.Add(this.rdbRaw);
            this.splitContainer.Panel1.Controls.Add(this.lblHttpResult);
            // 
            // splitContainer.Panel2
            // 
            this.splitContainer.Panel2.Controls.Add(this.webBrowser);
            this.splitContainer.Panel2.Controls.Add(this.txtResult);
            this.splitContainer.Panel2.Controls.Add(this.jsonTreeView);
            this.splitContainer.Size = new System.Drawing.Size(476, 397);
            this.splitContainer.SplitterDistance = 25;
            this.splitContainer.SplitterWidth = 1;
            this.splitContainer.TabIndex = 9;
            // 
            // rdbHtml
            // 
            this.rdbHtml.AutoSize = true;
            this.rdbHtml.Location = new System.Drawing.Point(243, 4);
            this.rdbHtml.Name = "rdbHtml";
            this.rdbHtml.Size = new System.Drawing.Size(55, 17);
            this.rdbHtml.TabIndex = 17;
            this.rdbHtml.Text = "HTML";
            this.rdbHtml.UseVisualStyleBackColor = true;
            this.rdbHtml.CheckedChanged += new System.EventHandler(this.rdbHtml_CheckedChanged);
            // 
            // progressBar
            // 
            this.progressBar.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.progressBar.Location = new System.Drawing.Point(0, 22);
            this.progressBar.MarqueeAnimationSpeed = 50;
            this.progressBar.Name = "progressBar";
            this.progressBar.Size = new System.Drawing.Size(476, 3);
            this.progressBar.Style = System.Windows.Forms.ProgressBarStyle.Marquee;
            this.progressBar.TabIndex = 16;
            this.progressBar.Visible = false;
            // 
            // lblVisualization
            // 
            this.lblVisualization.AutoSize = true;
            this.lblVisualization.Location = new System.Drawing.Point(7, 6);
            this.lblVisualization.Name = "lblVisualization";
            this.lblVisualization.Size = new System.Drawing.Size(68, 13);
            this.lblVisualization.TabIndex = 15;
            this.lblVisualization.Text = "Visualization:";
            // 
            // rdbJTree
            // 
            this.rdbJTree.AutoSize = true;
            this.rdbJTree.Location = new System.Drawing.Point(185, 4);
            this.rdbJTree.Name = "rdbJTree";
            this.rdbJTree.Size = new System.Drawing.Size(52, 17);
            this.rdbJTree.TabIndex = 14;
            this.rdbJTree.Text = "JTree";
            this.rdbJTree.UseVisualStyleBackColor = true;
            this.rdbJTree.CheckedChanged += new System.EventHandler(this.rdbJTree_CheckedChanged);
            // 
            // rdbJson
            // 
            this.rdbJson.AutoSize = true;
            this.rdbJson.Location = new System.Drawing.Point(132, 4);
            this.rdbJson.Name = "rdbJson";
            this.rdbJson.Size = new System.Drawing.Size(47, 17);
            this.rdbJson.TabIndex = 13;
            this.rdbJson.Text = "Json";
            this.rdbJson.UseVisualStyleBackColor = true;
            this.rdbJson.CheckedChanged += new System.EventHandler(this.rdbJson_CheckedChanged);
            // 
            // rdbRaw
            // 
            this.rdbRaw.AutoSize = true;
            this.rdbRaw.Checked = true;
            this.rdbRaw.Location = new System.Drawing.Point(79, 4);
            this.rdbRaw.Name = "rdbRaw";
            this.rdbRaw.Size = new System.Drawing.Size(47, 17);
            this.rdbRaw.TabIndex = 12;
            this.rdbRaw.TabStop = true;
            this.rdbRaw.Text = "Raw";
            this.rdbRaw.UseVisualStyleBackColor = true;
            this.rdbRaw.CheckedChanged += new System.EventHandler(this.rdbRaw_CheckedChanged);
            // 
            // webBrowser
            // 
            this.webBrowser.Dock = System.Windows.Forms.DockStyle.Fill;
            this.webBrowser.Location = new System.Drawing.Point(0, 0);
            this.webBrowser.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser.Name = "webBrowser";
            this.webBrowser.Size = new System.Drawing.Size(476, 371);
            this.webBrowser.TabIndex = 10;
            this.webBrowser.Visible = false;
            // 
            // txtResult
            // 
            this.txtResult.BackColor = System.Drawing.SystemColors.Window;
            this.txtResult.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtResult.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtResult.Location = new System.Drawing.Point(0, 0);
            this.txtResult.MaxLength = 2147483647;
            this.txtResult.Multiline = true;
            this.txtResult.Name = "txtResult";
            this.txtResult.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtResult.Size = new System.Drawing.Size(476, 371);
            this.txtResult.TabIndex = 4;
            // 
            // FrmResult
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(479, 397);
            this.Controls.Add(this.splitContainer);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(400, 140);
            this.Name = "FrmResult";
            this.Text = "Web Request";
            this.Shown += new System.EventHandler(this.frmResult_Shown);
            this.splitContainer.Panel1.ResumeLayout(false);
            this.splitContainer.Panel1.PerformLayout();
            this.splitContainer.Panel2.ResumeLayout(false);
            this.splitContainer.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).EndInit();
            this.splitContainer.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label lblHttpResult;
        private Alex75.JsonViewer.WindowsForm.JsonTreeView jsonTreeView;
        private System.Windows.Forms.SplitContainer splitContainer;
        private System.Windows.Forms.TextBox txtResult;
        private System.Windows.Forms.Label lblVisualization;
        private System.Windows.Forms.RadioButton rdbJTree;
        private System.Windows.Forms.RadioButton rdbJson;
        private System.Windows.Forms.RadioButton rdbRaw;
        private System.Windows.Forms.ProgressBar progressBar;
        private System.Windows.Forms.RadioButton rdbHtml;
        private System.Windows.Forms.WebBrowser webBrowser;
    }
}