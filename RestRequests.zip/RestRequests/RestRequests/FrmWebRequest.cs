﻿using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace RestRequests
{
    using RestRequests.Properties;
    using System.ComponentModel;
    using System.IO;

    public partial class FrmWebRequest : Form
    {
        public FrmWebRequest()
        {
            InitializeComponent();
            cboMethod.SelectedIndex =
            cboEncoding.SelectedIndex =
            cboContentType.SelectedIndex =
            cboAuthorizationType.SelectedIndex = 0;
            setLayout();
            Settings.Default.PropertyChanged += default_PropertyChanged;
        }

        private void setLayout()
        {
            txtContent.ForeColor = SettingsController.LayoutSettings.ForeColor;
            txtContent.Font = SettingsController.LayoutSettings.Font;
        }

        private void default_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == SettingsController.LayoutSettingsName)
                setLayout();
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtUrl.Text))
                return;
            if (!txtUrl.Text.ToLower().StartsWith("http"))
                txtUrl.Text = "http://" + txtUrl.Text;
            HttpMethod method;
            switch (cboMethod.SelectedItem?.ToString())
            {
                case "POST":
                    method = HttpMethod.Post;
                    break;
                case "DELETE":
                    method = HttpMethod.Delete;
                    break;
                case "PUT":
                    method = HttpMethod.Put;
                    break;
                case "OPTIONS":
                    method = HttpMethod.Options;
                    break;
                default:
                    method = HttpMethod.Get;
                    break;
            }
            var request = new HttpRequestMessage(method, txtUrl.Text);
            if (!string.IsNullOrWhiteSpace(cboContentType.Text) && !string.IsNullOrWhiteSpace(txtContent.Text))
            {
                Encoding encoding;
                switch (cboEncoding.SelectedItem?.ToString())
                {
                    case "ANSI": encoding = Encoding.Default; break;
                    case "UTF-7": encoding = Encoding.UTF7; break;
                    case "UTF-16 Big Endian": encoding = Encoding.BigEndianUnicode; break;
                    case "UTF-16 Little Endian": encoding = Encoding.Unicode; break;
                    case "UTF-32": encoding = Encoding.UTF32; break;
                    case "ACII": encoding = Encoding.ASCII; break;
                    default: encoding = Encoding.UTF8; break;
                }
                request.Content = new StringContent(txtContent.Text, encoding, cboContentType.Text);
            }
            if (cboAuthorizationType.Text == "Bearer Token")
            {
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", txtAuthorization.Text);
            }
            ShowResult(method, request);
        }

        private void ShowResult(HttpMethod method, HttpRequestMessage request)
        {
            if (method == HttpMethod.Get)
            {
                if (txtUrl.Text.EndsWith("?wsdl"))
                {
                    new FrmResultSvc(txtUrl.Text, request).Show();
                    return;
                }
            }
            new FrmResult(txtUrl.Text, request).Show();
        }

        private void proxyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var frmProxySettings = new FrmProxySettings();
            frmProxySettings.ShowDialog();
        }

        private void layoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var fontDialog = new FontDialog();
            fontDialog.ShowColor = true;
            if (SettingsController.LayoutSettings?.Font != null)
            {
                fontDialog.Color = SettingsController.LayoutSettings.ForeColor;
                fontDialog.Font = SettingsController.LayoutSettings.Font;
            }
            if (fontDialog.ShowDialog() != DialogResult.OK)
                return;
            SettingsController.LayoutSettings = new LayoutSettingsModel(fontDialog.Font, fontDialog.Color);
        }

        private void viewToolStripMenuItem_MouseUp(object sender, MouseEventArgs e)
        {
            default_MouseUp<FrmResult>(e);
        }

        private void interestToolStripMenuItem_MouseUp(object sender, MouseEventArgs e)
        {
            default_MouseUp<CalculadoraJurosCompostos.FrmCalculadora>(e);
        }

        private void convertToolStripMenuItem_MouseUp(object sender, MouseEventArgs e)
        {
            default_MouseUp<HashConverter.FrmFileConveter>(e);
        }

        private void promptToolStripMenuItem_MouseUp(object sender, MouseEventArgs e)
        {
            default_MouseUp<TabCmd.PromptForm>(e);
        }

        private void default_MouseUp<T>(MouseEventArgs e) where T : Form, new()
        {
            var frm = new T();
            if (ModifierKeys == Keys.Shift || e.Button == MouseButtons.Right)
            {
                var act = new Action(() => frm.ShowDialog());
                var thread = new Thread(new ThreadStart(act)) { IsBackground = false };
                thread.SetApartmentState(ApartmentState.STA);
                thread.Start();
            }
            else
            {
                frm.Show();
            }
        }

        private void txtUrl_Leave(object sender, EventArgs e)
        {
            var url = txtUrl.Text.ToLower();
            if (url.EndsWith(".svc") || url.EndsWith(".svc?wsdl"))
                cboMethod.SelectedItem = "GET";
        }

        private void FrmWebRequest_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (!Directory.Exists("Temp"))
                return;
            try
            {
                var files = Directory.EnumerateFiles("Temp");
                foreach (string file in files)
                {
                    try
                    {
                        File.Delete(file);
                    }
                    catch { }
                }
                Directory.Delete("Temp");
            }
#if(DEBUG)
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
            }
#else
            catch
            {
                //Não conseguiu apagar a pasta.
                //Provavelmente porque existe instância em execução.
            }
#endif
        }
    }
}