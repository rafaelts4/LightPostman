﻿using Newtonsoft.Json;
using System;
using System.Diagnostics;

namespace RestRequests
{
    public class SettingsController
    {
        public static readonly string ProxySettingsName = nameof(Properties.Settings.Default.ProxyJsonSettings);
        public static readonly string LayoutSettingsName = nameof(Properties.Settings.Default.LayoutJsonSettings);

        public static ProxySettingsModel ProxySettings
        {
            get
            {
                return getGeneric<ProxySettingsModel>(ProxySettingsName);
            }
            set
            {
                setGeneric(ProxySettingsName, value);
            }
        }

        public static LayoutSettingsModel LayoutSettings
        {
            get
            {
                return getGeneric<LayoutSettingsModel>(LayoutSettingsName);
            }
            set
            {
                setGeneric(LayoutSettingsName, value);
            }
        }

        private static T getGeneric<T>(string propertyName) where T : new()
        {
            T settings = default(T);
            var json = Properties.Settings.Default[propertyName].ToString();
            try
            {
                if (string.IsNullOrWhiteSpace(json))
                    settings = new T();
                else
                    settings = JsonConvert.DeserializeObject<T>(json);
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
                Properties.Settings.Default[propertyName] = string.Empty;
                settings = new T();
            }
            return settings;
        }

        private static void setGeneric<T>(string propertyName, T property) where T : new()
        {
            Properties.Settings.Default[propertyName] = property.ToString();
            Properties.Settings.Default.Save();            
        }
    }
}
