﻿using System;
using System.Windows.Forms;

namespace RestRequests
{
    public partial class ParameterComboBox : ComboBox
    {        
        public ParameterComboBox()
        {
            InitializeComponent();
            DropDownStyle = ComboBoxStyle.Simple;
            SelectedValueChanged += ParameterComboBox_SelectedValueChanged;
            KeyPress += ParameterComboBox_KeyPress;            
        }

        private void ParameterComboBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r' && SelectedItem == null)
            {
                Items.Add(Text);
                Text = String.Empty;                
            }
            else if(SelectedItem != null)
            {
                SelectedItem = SelectedItem.ToString() + e.KeyChar;
            }
        }

        private void ParameterComboBox_SelectedValueChanged(object sender, EventArgs e)
        {
            if (SelectedItem != null)
            {
                SelectedItem = Text;
            }
        }
    }
}
