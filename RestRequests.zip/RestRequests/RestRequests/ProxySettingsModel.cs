﻿using Newtonsoft.Json;

namespace RestRequests
{
    public class ProxySettingsModel
    {
        public ProxySettingsModel()
        {
            Credentials = new Credentials();
            ServerCredentials = new Credentials();
        }

        public ProxySettingsModel(string uri, uint port, bool bypassyOnLocal, bool needServerAuthentication, bool preAuthenticate)
        {
            Uri = uri;
            Port = port;
            BypassyOnLocal = bypassyOnLocal;            
            NeedServerAuthentication = needServerAuthentication;
            PreAuthenticate = preAuthenticate;
        }

        public ProxySettingsModel(string uri, uint port, bool bypassyOnLocal, bool useDefaultCredentials, bool needServerAuthentication, bool preAuthenticate, string userName, string password)
            : this(uri, port, bypassyOnLocal, needServerAuthentication, preAuthenticate)
        {
            Credentials = new Credentials(userName, password, useDefaultCredentials);
            ServerCredentials = new Credentials();
        }

        public ProxySettingsModel(string uri, uint port, bool bypassyOnLocal, bool useDefaultCredentials, bool needServerAuthentication, bool preAuthenticate, string userName, string password, string serverUser, string serverPassword, bool useServerDefaultCredentials)
            : this(uri, port, bypassyOnLocal, needServerAuthentication, preAuthenticate)
        {
            Credentials = new Credentials(userName, password, useDefaultCredentials);
            ServerCredentials = new Credentials(serverUser, serverPassword, useServerDefaultCredentials);
        }

        public string Uri { get; set; }
        public uint Port { get; set; }
        public Credentials Credentials { get; set; }
        public bool BypassyOnLocal { get; set; }           
        public bool NeedServerAuthentication { get; set; }
        public bool PreAuthenticate { get; set; }
        public Credentials ServerCredentials { get; set; }

        public override string ToString()
        {
            return JsonConvert.SerializeObject(this);
        }
    }

    public class Credentials
    {
        public Credentials() { }
        public Credentials(string userName, string password)
        {
            UserName = userName;
            Password = password;
        }
        public Credentials(string userName, string password, bool useDefaultCredentials)
            : this(userName, password)
        {
            UseDefaultCredentials = useDefaultCredentials;
        }

        public bool UseDefaultCredentials { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
    }
}
