﻿using System;

namespace RestRequests
{
    internal static class TypeExtension
    {
        public static bool IsSimple(this Type type)
        {
            return type.IsPrimitive
                || type.FullName == "System.DateTime"
                || type.FullName == "System.Decimal"
                || type.FullName == "System.String";
        }

        public static bool IsNumber(this Type type)
        {
            return IsInteger(type) || IsDecimal(type);
        }

        public static bool IsInteger(this Type type)
        {            
            switch (type.FullName)
            {
                case "System.Int16":
                case "System.UInt16":
                case "System.Int32":
                case "System.UInt32":
                case "System.Int64":
                case "System.UInt64":
                    return true;
            }
            return false;
        }

        public static bool IsDecimal(this Type type)
        {
            switch (type.FullName)
            {
                case "System.Single":
                case "System.Double":
                case "System.Decimal":
                    return true;
            }
            return false;
        }

        public static object ChangeType(this Type type, string value)
        {
            object result;
            if (string.IsNullOrWhiteSpace(value))
            {
                // Se a string for nula ou vazia e o tipo for um ValueType 
                // como inteiro, por exemplo, então preenche o valor com o valor padrão,
                // para não falhar na converter.
                if (type.IsValueType && type.FullName != "System.String")
                    value = Activator.CreateInstance(type)?.ToString();
                if (value == null)
                    return null;
            }
            var underlyingType = Nullable.GetUnderlyingType(type);
            if (underlyingType == null)
                result = Convert.ChangeType(value, type);
            else
                result = Convert.ChangeType(value, underlyingType);
            return result;
        }
    }
}