﻿using Newtonsoft.Json;
using System.Drawing;

namespace RestRequests
{
    public class LayoutSettingsModel
    {
        public Font Font { get; set; }
        public Color ForeColor { get; set; }


        public LayoutSettingsModel()
        {
            this.ForeColor = Color.Black;
        }

        public LayoutSettingsModel(Font font, Color foreColor)
        {
            this.Font = font;
            this.ForeColor = foreColor;
        }

        public override string ToString()
        {
            return JsonConvert.SerializeObject(this);
        }
    }
}
