﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace RestRequests
{
    public partial class FrmProxySettings : Form
    {
        public FrmProxySettings()
        {
            InitializeComponent();
        }

        private void FrmProxySettings_Load(object sender, EventArgs e)
        {
            var proxySettings = SettingsController.ProxySettings;
            if (proxySettings == null) return;
            txtProxyUrl.Text = proxySettings.Uri;
            txtProxyPort.Text = proxySettings.Port.ToString();
            chkBypassOnLocal.Checked = proxySettings.BypassyOnLocal;
            chkNeedServerAuthentication.Checked = proxySettings.NeedServerAuthentication;
            chkPreAuthenticate.Checked = proxySettings.PreAuthenticate;
            chkUseDefaultCredentials.Checked = proxySettings.Credentials.UseDefaultCredentials;
            txtProxyUser.Text = proxySettings.Credentials.UserName;
            txtProxyPassword.Text = proxySettings.Credentials.Password;
            chkServerDefaultCredentials.Checked = proxySettings.ServerCredentials.UseDefaultCredentials;
            txtServerUser.Text = proxySettings.ServerCredentials.UserName;
            txtServerPassword.Text = proxySettings.ServerCredentials.Password;
        }

        private void txtPort_KeyPress(object sender, KeyPressEventArgs e)
        {
            string allowed = "0123456789\b\u0016";
            if (!allowed.Contains(e.KeyChar))
                e.Handled = true;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (!uint.TryParse(txtProxyPort.Text, out uint port) || port <= 0)
            {
                MessageBox.Show("Invalid Port", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtProxyPort.Focus();
                txtProxyPort.SelectAll();
                return;
            }
            if (!txtProxyUrl.Text.StartsWith("http"))
                txtProxyUrl.Text = "http://" + txtProxyUrl.Text;
            SettingsController.ProxySettings = new ProxySettingsModel(
                uri: txtProxyUrl.Text,
                port: port,
                bypassyOnLocal: chkBypassOnLocal.Checked,
                useDefaultCredentials: chkUseDefaultCredentials.Checked,
                needServerAuthentication: chkNeedServerAuthentication.Checked,
                preAuthenticate: chkPreAuthenticate.Checked,
                userName: txtProxyUser.Text,
                password: txtProxyPassword.Text,
                serverUser: txtServerUser.Text,
                serverPassword: txtServerPassword.Text,
                useServerDefaultCredentials: chkServerDefaultCredentials.Checked
            );
            DialogResult = DialogResult.OK;
            Close();
        }

        private void chkNeedServerAuthentication_CheckedChanged(object sender, EventArgs e)
        {
            gpbServerAuthentication.Enabled = chkNeedServerAuthentication.Checked;
        }
    }
}
