﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace JsonFormater
{
    public partial class DraggableForm : Form
    {

        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern bool ReleaseCapture();

        static DraggableForm()
        {
            Application.AddMessageFilter(new MouseMessageFilter());
        }

        public DraggableForm()
        {
            InitializeComponent();
            MouseMessageFilter.MouseMove += DraggableForm_MouseMove;
        }

        private void menuTop_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void lblClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void lblButton_MouseHover(object sender, EventArgs e)
        {
            var ctrl = sender as ToolStripMenuItem;
            var font = new Font(ctrl.Font, FontStyle.Bold);
            ctrl.Font = font;
        }

        private void lblButton_MouseLeave(object sender, EventArgs e)
        {
            var ctrl = sender as ToolStripMenuItem;
            var font = new Font(ctrl.Font, FontStyle.Regular);
            ctrl.Font = font;
        }

        private void DraggableForm_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {
            e.IsInputKey = true;
        }

        private void lblMaximize_Click(object sender, EventArgs e)
        {
            if (WindowState == FormWindowState.Normal)
            {
                WindowState = FormWindowState.Maximized;
                lblMaximize.Text = "2";
            }
            else
            {
                WindowState = FormWindowState.Normal;
                lblMaximize.Text = "1";
            }
        }

        private void lblMinimize_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void lblPlus_Click(object sender, EventArgs e)
        {
            AddNewViewer();
        }

        protected void AddNewViewer()
        {
            var frmViewer = new FrmViewer();
            frmViewer.MdiParent = this;
            if (MdiChildren.Length < 2)
                frmViewer.WindowState = FormWindowState.Maximized;
            else
                frmViewer.WindowState = FormWindowState.Normal;
            frmViewer.Show();
            LayoutMdi(MdiLayout.TileVertical);
        }


        private void DraggableForm_MouseMove(object sender, MouseEventArgs e)
        {
            var cursor = isMouseOverMargin(e);
            if (cursor == null)
                return;
            Cursor.Current = cursor;
            if (e.Button != MouseButtons.Left)
            {                
                return;
            }
            if (cursor == Cursors.SizeWE)
            {
                Width = e.X - Location.X + 5;
                Height = e.Y - Location.Y + 5;
            }
            if (cursor == Cursors.SizeWE)
            {
                Width = e.X - Location.X + 5;
            }
            if (cursor == Cursors.SizeNS)
            {
                Height = e.Y - Location.Y + 5;
            }
            System.Diagnostics.Debug.WriteLine($"{DateTime.Now.ToLongTimeString()} - cursor: {cursor.ToString()}");
        }

        private Cursor isMouseOverMargin(MouseEventArgs e)
        {
            const int GRIP = 15;
            var actualX = e.X - Location.X;
            var actualY = e.Y - Location.Y;

            if(actualX > Width - GRIP && actualX <= Width && actualY > Height - GRIP && actualY <= Height)
                return Cursors.SizeNWSE;

            if (actualX > 0 && actualX < GRIP)
                return Cursors.SizeWE;

            if (actualX > Width - GRIP && actualX <= Width)
                return Cursors.SizeWE;

            if (actualY > 0 && actualY < GRIP)
                return Cursors.SizeNS;

            if (actualY > Height - GRIP && actualY <= Height)
                return Cursors.SizeNS;

            return null;
        }
    }
}