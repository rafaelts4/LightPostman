﻿using Newtonsoft.Json;
using System;
using System.Drawing;
using System.Windows.Forms;

namespace JsonFormater
{
    public partial class FrmViewer : Form
    {
        private string rawResult;        

        public FrmViewer()
        {
            InitializeComponent();
            jsonTreeView.NodeMouseClick += JsonTreeView_NodeMouseClick;
        }

        private void JsonTreeView_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            var txt = e.Node.Text;
            try
            {
                int idx = txt.IndexOf(":");
                if (idx > -1)
                    txt = txt.Substring(idx + 1).Trim();
            }
            finally
            {
                if(!string.IsNullOrWhiteSpace(txt))
                    Clipboard.SetText(txt);
            }
        }       
       
        private void rdbRaw_CheckedChanged(object sender, EventArgs e)
        {
            txtResult.Text = rawResult;
            txtResult.Visible = true;
            jsonTreeView.Visible = false;
        }

        private void rdbJson_CheckedChanged(object sender, EventArgs e)
        {
            if (!rdbJson.Checked)
                return;
            try
            {
                var jsonObject = JsonConvert.DeserializeObject(rawResult);
                var identedJson = JsonConvert.SerializeObject(jsonObject, Formatting.Indented);
                txtResult.Text = identedJson;
                txtResult.Visible = true;
                jsonTreeView.Visible = false;
            }
            catch
            {
                rdbRaw.Checked = true;
                MessageBox.Show("Content is not in correct format.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void rdbJTree_CheckedChanged(object sender, EventArgs e)
        {
            if (!rdbJTree.Checked)
                return;
            try
            {
                jsonTreeView.ShowJson(txtResult.Text);
                jsonTreeView.ExpandAll();
                txtResult.Visible = false;
                jsonTreeView.Visible = true;
            }
            catch(Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
                rdbRaw.Checked = true;
                MessageBox.Show("Content is not in correct format.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }      

        private void PrintException(Exception ex, Control ctrl)
        {
            ctrl.ForeColor = Color.Red;
            ctrl.Text = ex.Message;
            var innerException = ex.InnerException;
            while (innerException != null)
            {
                ctrl.Text += Environment.NewLine;
                ctrl.Text += innerException.Message;
                innerException = innerException.InnerException;
            }
        }
        
        private void txtResult_TextChanged(object sender, EventArgs e)
        {
            rawResult = txtResult.Text;
        }

        private TreeNode IterateTreeNode(ref TreeNode nodes)
        {
            TreeNode retorno = null;
            foreach (var obj in nodes.Nodes)
            {
                var node = obj as TreeNode;
                if (string.IsNullOrEmpty(node?.Text) && node?.NextNode != null)
                {
                    retorno = node?.NextNode;
                    IterateTreeNode(ref retorno);
                }
            }
            return retorno;
        }       
    }
}