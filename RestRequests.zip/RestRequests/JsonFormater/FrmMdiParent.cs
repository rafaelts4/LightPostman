﻿using System;
using System.Windows.Forms;

namespace JsonFormater
{
    public partial class FrmMdiParent : DraggableForm
    {
        public FrmMdiParent()
        {
            InitializeComponent();            
        }

        private void FrmMdiParent_Load(object sender, EventArgs e)
        {            
            AddNewViewer();
        }

        private void FrmMdiParent_Resize(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileVertical);
        }      
    }
}
