﻿using System.Drawing;
using System.Windows.Forms;

namespace JsonFormater
{
    class MouseMessageFilter : IMessageFilter
    {
        public static event MouseEventHandler MouseMove;

        const int WM_MOUSEMOVE = 0x0200;
        const int WM_LBUTTONDOWN = 0x0201;
        const int WM_LBUTTONUP = 0x0202;
        const int WM_RBUTTONDOWN = 0x0204;
        const int WM_RBUTTONUP = 0x0205;
        private MouseButtons? lastState = MouseButtons.None;

        public bool PreFilterMessage(ref Message msg)
        {
            MouseEventArgs args = null;
            Point mousePosition;
            if (msg.Msg == WM_MOUSEMOVE || msg.Msg == WM_LBUTTONUP || msg.Msg == WM_RBUTTONUP)
                lastState = (msg.Msg == WM_MOUSEMOVE) ? lastState : MouseButtons.None;
            else if (msg.Msg == WM_MOUSEMOVE)
                lastState = MouseButtons.None;
            else if (msg.Msg == WM_LBUTTONDOWN)
                lastState = MouseButtons.Left;
            else if (msg.Msg == WM_RBUTTONDOWN)
                lastState = MouseButtons.Right;

            mousePosition = Control.MousePosition;
            args = new MouseEventArgs(lastState.Value, 0, mousePosition.X, mousePosition.Y, 0);
            MouseMove?.Invoke(null, args);

            return false;
        }
    }
}
