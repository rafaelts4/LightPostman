﻿namespace JsonFormater
{
    partial class FrmViewer
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

       #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmViewer));
            this.splitContainer = new System.Windows.Forms.SplitContainer();
            this.lblVisualization = new System.Windows.Forms.Label();
            this.rdbJTree = new System.Windows.Forms.RadioButton();
            this.rdbJson = new System.Windows.Forms.RadioButton();
            this.rdbRaw = new System.Windows.Forms.RadioButton();
            this.txtResult = new System.Windows.Forms.TextBox();
            this.jsonTreeView = new Alex75.JsonViewer.WindowsForm.JsonTreeView();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).BeginInit();
            this.splitContainer.Panel1.SuspendLayout();
            this.splitContainer.Panel2.SuspendLayout();
            this.splitContainer.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer
            // 
            this.splitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer.Location = new System.Drawing.Point(0, 0);
            this.splitContainer.Name = "splitContainer";
            this.splitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer.Panel1
            // 
            this.splitContainer.Panel1.Controls.Add(this.lblVisualization);
            this.splitContainer.Panel1.Controls.Add(this.rdbJTree);
            this.splitContainer.Panel1.Controls.Add(this.rdbJson);
            this.splitContainer.Panel1.Controls.Add(this.rdbRaw);
            // 
            // splitContainer.Panel2
            // 
            this.splitContainer.Panel2.Controls.Add(this.txtResult);
            this.splitContainer.Panel2.Controls.Add(this.jsonTreeView);
            this.splitContainer.Size = new System.Drawing.Size(479, 397);
            this.splitContainer.SplitterDistance = 25;
            this.splitContainer.SplitterWidth = 1;
            this.splitContainer.TabIndex = 9;
            // 
            // lblVisualization
            // 
            this.lblVisualization.AutoSize = true;
            this.lblVisualization.Location = new System.Drawing.Point(7, 7);
            this.lblVisualization.Name = "lblVisualization";
            this.lblVisualization.Size = new System.Drawing.Size(68, 13);
            this.lblVisualization.TabIndex = 15;
            this.lblVisualization.Text = "Visualization:";
            // 
            // rdbJTree
            // 
            this.rdbJTree.AutoSize = true;
            this.rdbJTree.Location = new System.Drawing.Point(185, 5);
            this.rdbJTree.Name = "rdbJTree";
            this.rdbJTree.Size = new System.Drawing.Size(52, 17);
            this.rdbJTree.TabIndex = 14;
            this.rdbJTree.Text = "JTree";
            this.rdbJTree.UseVisualStyleBackColor = true;
            this.rdbJTree.CheckedChanged += new System.EventHandler(this.rdbJTree_CheckedChanged);
            // 
            // rdbJson
            // 
            this.rdbJson.AutoSize = true;
            this.rdbJson.Location = new System.Drawing.Point(132, 5);
            this.rdbJson.Name = "rdbJson";
            this.rdbJson.Size = new System.Drawing.Size(47, 17);
            this.rdbJson.TabIndex = 13;
            this.rdbJson.Text = "Json";
            this.rdbJson.UseVisualStyleBackColor = true;
            this.rdbJson.CheckedChanged += new System.EventHandler(this.rdbJson_CheckedChanged);
            // 
            // rdbRaw
            // 
            this.rdbRaw.AutoSize = true;
            this.rdbRaw.Checked = true;
            this.rdbRaw.Location = new System.Drawing.Point(79, 5);
            this.rdbRaw.Name = "rdbRaw";
            this.rdbRaw.Size = new System.Drawing.Size(47, 17);
            this.rdbRaw.TabIndex = 12;
            this.rdbRaw.TabStop = true;
            this.rdbRaw.Text = "Raw";
            this.rdbRaw.UseVisualStyleBackColor = true;
            this.rdbRaw.CheckedChanged += new System.EventHandler(this.rdbRaw_CheckedChanged);
            // 
            // txtResult
            // 
            this.txtResult.BackColor = System.Drawing.SystemColors.Window;
            this.txtResult.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtResult.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txtResult.Location = new System.Drawing.Point(0, 0);
            this.txtResult.Multiline = true;
            this.txtResult.Name = "txtResult";
            this.txtResult.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtResult.Size = new System.Drawing.Size(479, 371);
            this.txtResult.TabIndex = 4;
            this.txtResult.TextChanged += new System.EventHandler(this.txtResult_TextChanged);            
            // 
            // jsonTreeView
            // 
            this.jsonTreeView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.jsonTreeView.FullRowSelect = true;
            this.jsonTreeView.ImageIndex = 0;
            this.jsonTreeView.LineColor = System.Drawing.Color.Empty;
            this.jsonTreeView.Location = new System.Drawing.Point(0, 0);
            this.jsonTreeView.Margin = new System.Windows.Forms.Padding(2);
            this.jsonTreeView.Name = "jsonTreeView";
            this.jsonTreeView.SelectedImageIndex = 0;
            this.jsonTreeView.Size = new System.Drawing.Size(479, 328);
            this.jsonTreeView.TabIndex = 9;
            this.jsonTreeView.Visible = false;
            // 
            // FrmViewer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(479, 397);
            this.Controls.Add(this.splitContainer);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmViewer";
            this.ShowIcon = false;
            this.Text = "JSON Viewer";
            this.splitContainer.Panel1.ResumeLayout(false);
            this.splitContainer.Panel1.PerformLayout();
            this.splitContainer.Panel2.ResumeLayout(false);
            this.splitContainer.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).EndInit();
            this.splitContainer.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private Alex75.JsonViewer.WindowsForm.JsonTreeView jsonTreeView;
        private System.Windows.Forms.SplitContainer splitContainer;
        private System.Windows.Forms.TextBox txtResult;
        private System.Windows.Forms.Label lblVisualization;
        private System.Windows.Forms.RadioButton rdbJTree;
        private System.Windows.Forms.RadioButton rdbJson;
        private System.Windows.Forms.RadioButton rdbRaw;
    }
}