﻿namespace JsonFormater
{
    partial class DraggableForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.lblClose = new System.Windows.Forms.ToolStripMenuItem();
            this.lblMaximize = new System.Windows.Forms.ToolStripMenuItem();
            this.lblMinimize = new System.Windows.Forms.ToolStripMenuItem();
            this.lblPlus = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip
            // 
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lblClose,
            this.lblMaximize,
            this.lblMinimize,
            this.lblPlus});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.menuStrip.Size = new System.Drawing.Size(520, 27);
            this.menuStrip.TabIndex = 3;
            this.menuStrip.MouseDown += new System.Windows.Forms.MouseEventHandler(this.menuTop_MouseDown);
            // 
            // lblClose
            // 
            this.lblClose.Font = new System.Drawing.Font("Wingdings 2", 9F);
            this.lblClose.Name = "lblClose";
            this.lblClose.Size = new System.Drawing.Size(30, 23);
            this.lblClose.Text = "Ï";
            this.lblClose.Click += new System.EventHandler(this.lblClose_Click);
            this.lblClose.MouseLeave += new System.EventHandler(this.lblButton_MouseLeave);
            this.lblClose.MouseHover += new System.EventHandler(this.lblButton_MouseHover);
            // 
            // lblMaximize
            // 
            this.lblMaximize.Font = new System.Drawing.Font("Webdings", 9F);
            this.lblMaximize.Name = "lblMaximize";
            this.lblMaximize.Size = new System.Drawing.Size(33, 23);
            this.lblMaximize.Text = "1";
            this.lblMaximize.Click += new System.EventHandler(this.lblMaximize_Click);
            this.lblMaximize.MouseLeave += new System.EventHandler(this.lblButton_MouseLeave);
            this.lblMaximize.MouseHover += new System.EventHandler(this.lblButton_MouseHover);
            // 
            // lblMinimize
            // 
            this.lblMinimize.Font = new System.Drawing.Font("Webdings", 9F);
            this.lblMinimize.Name = "lblMinimize";
            this.lblMinimize.Size = new System.Drawing.Size(33, 23);
            this.lblMinimize.Text = "0";
            this.lblMinimize.Click += new System.EventHandler(this.lblMinimize_Click);
            this.lblMinimize.MouseLeave += new System.EventHandler(this.lblButton_MouseLeave);
            this.lblMinimize.MouseHover += new System.EventHandler(this.lblButton_MouseHover);
            // 
            // lblPlus
            // 
            this.lblPlus.Font = new System.Drawing.Font("Wingdings 2", 9F);
            this.lblPlus.Name = "lblPlus";
            this.lblPlus.Size = new System.Drawing.Size(30, 23);
            this.lblPlus.Text = "È";
            this.lblPlus.Click += new System.EventHandler(this.lblPlus_Click);
            this.lblPlus.MouseLeave += new System.EventHandler(this.lblButton_MouseLeave);
            this.lblPlus.MouseHover += new System.EventHandler(this.lblButton_MouseHover);
            // 
            // DraggableForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(520, 500);
            this.Controls.Add(this.menuStrip);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.IsMdiContainer = true;
            this.KeyPreview = true;
            this.Location = new System.Drawing.Point(100, 25);
            this.MainMenuStrip = this.menuStrip;
            this.Name = "DraggableForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "DraggableBorderlessForm";
            this.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.DraggableForm_PreviewKeyDown);
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolStripMenuItem lblClose;
        private System.Windows.Forms.ToolStripMenuItem lblMaximize;
        private System.Windows.Forms.ToolStripMenuItem lblMinimize;
        private System.Windows.Forms.ToolStripMenuItem lblPlus;
    }
}