﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("JSON Viewer")]
[assembly: AssemblyDescription("Windows Form control for showing a JSON file content.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Alessandro Piccione")]
[assembly: AssemblyProduct("JSON Viewer")]
[assembly: AssemblyCopyright("Copyright © 2016")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]
[assembly: Guid("eb2e042c-5214-441b-863e-e528b4d0ab50")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Build and Revision Numbers 
// by using the '*' as shown below:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("0.2.*")]
[assembly: AssemblyFileVersion("1.0.0.0")]
