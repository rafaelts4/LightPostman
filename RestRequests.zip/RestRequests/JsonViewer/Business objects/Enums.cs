﻿namespace Alex75.JsonViewer.BusinessObjects
{
    public enum NodeType
    {
        Value,
        Array,
        Object,
    }
}
