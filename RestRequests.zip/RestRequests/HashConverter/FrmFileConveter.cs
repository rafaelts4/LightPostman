﻿using System;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace HashConverter
{
    public partial class FrmFileConveter : Form
    {
        public FrmFileConveter()
        {
            InitializeComponent();
        }

        private string CreateMD5(byte[] inputBytes)
        {
            // Use input string to calculate MD5 hash            
            using (var md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] hashBytes = md5.ComputeHash(inputBytes);

                // Convert the byte array to hexadecimal string
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < hashBytes.Length; i++)
                {
                    sb.Append(hashBytes[i].ToString("X2"));
                }
                return sb.ToString();
            }
        }

        private void btnOpen_Click(object sender, EventArgs e)
        {
            if (openFileDialog.ShowDialog() != DialogResult.OK)
                return;
            txtFile.Text = openFileDialog.FileName;
            var fileBytes = File.ReadAllBytes(openFileDialog.FileName);
            txtBase64.Text = Convert.ToBase64String(fileBytes);
            txtHash.Text = CreateMD5(fileBytes);            
        }

        private void txtBox_Enter(object sender, EventArgs e)
        {
            var txtBox = sender as TextBox;
            if (string.IsNullOrEmpty(txtBox.Text)) return;
            toolTip.RemoveAll();            
            Clipboard.SetText(txtBox.Text);
            txtBox.SelectionStart = 0;
            txtBox.SelectionLength = txtBox.Text.Length;
            var cursorPosition = PointToClient(Cursor.Position);
            toolTip.Show("Texto copiado!", this, cursorPosition.X, cursorPosition.Y, 1500);
        }
    }
}
